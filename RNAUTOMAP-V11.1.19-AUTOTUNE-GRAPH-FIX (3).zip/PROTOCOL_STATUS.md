# Protocol status

This version intentionally leaves `MainActivity.java` unchanged from the source ZIP supplied as V11.1.17. Bluetooth/live operation must still be tested on the user's phone and ECU after building.

Map export is for manual use only. Fuel Correction ECU write is not implemented/verified.


const TPS=[0,2,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,100], RPM=[];for(let r=1000;r<=16000;r+=250)RPM.push(r);
let corr={};TPS.forEach(t=>{corr[t]={};RPM.forEach(r=>corr[t][r]=0)});
let active={rpm:null,tps:null}, live=false, baseData=null;
let targets={low:13.2,mid:13.2,high:13.2};
try{const s=JSON.parse(localStorage.getItem('rnautomap_targets')||'null');if(s)targets=Object.assign(targets,s)}catch(e){}
function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));const el=document.getElementById(id);if(el)el.classList.add('active');document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('on'));const n=document.getElementById('n-'+id);if(n)n.classList.add('on');if(id==='auto'){loadTargetInputs();draw3d();updateBaseCell()}if(id==='fuel')renderFuel();if(id==='posisi')renderPos();if(id==='base'){setTimeout(syncBaseFromCalculator,350)}}
function scan(){AndroidBT.scan();show('settings')}
function btScanStarted(){document.getElementById('devices').innerHTML='<div class="hint">Mencari perangkat...</div>'}
function btFound(name,addr,juken){let d=document.getElementById('devices');let b=document.createElement('button');b.className='btn';b.style.width='100%';b.style.margin='4px 0';b.innerText=(juken?'★ ':'')+name+' • '+addr;b.onclick=()=>AndroidBT.pairAndConnect(addr);d.appendChild(b)}
function btPairingStarted(addr){document.getElementById('connTitle').innerText='PAIRING MODUL JUKEN';document.getElementById('connSub').innerText='Masukkan/konfirmasi kode yang diminta modul Bluetooth JUKEN';document.getElementById('status').innerText='PAIRING'}
function btBonded(addr){document.getElementById('connTitle').innerText='JUKEN SUDAH PAIRED';document.getElementById('connSub').innerText='Bonded ✓ • membuka koneksi ECU';document.getElementById('status').innerText='PAIRED'}
function btSocketConnected(name){document.getElementById('connTitle').innerText='BLUETOOTH JUKEN TERHUBUNG';document.getElementById('connSub').innerText='Socket aktif • validasi ECU JUKEN...';document.getElementById('status').innerText='VALIDATING ECU'}
function btPairingNeeded(addr){try{AndroidBT.pairAndConnect(addr)}catch(e){btError(e)}}
function btConnecting(s){document.getElementById('connSub').innerText=s;document.getElementById('status').innerText='CONNECTING'}
function btConnected(name){document.getElementById('connTitle').innerHTML='<span class="ok">● TERHUBUNG KE JUKEN</span>';document.getElementById('connSub').innerText=name;document.getElementById('status').innerText='READY'}
function btMapStatus(s){const el=document.getElementById('connSub');if(el)el.innerText=s}
function btLiveStarted(){live=true;document.getElementById('status').innerText='LIVE • MENUNGGU RX'}
function btEcuIdentity(id){window.jukenEcuIdentity=String(id||'');document.getElementById('connTitle').innerHTML='<span class="ok">● ECU JUKEN VALID</span>';document.getElementById('connSub').innerText='ECU • '+window.jukenEcuIdentity;document.getElementById('status').innerText='ECU CONNECTED';}
function btComm(bytes){window.jukenRxBytes=Number(bytes)||0;const el=document.getElementById('connSub');if(el&&bytes>0)el.innerText='JUKEN RX • '+bytes+' byte';}
function btLiveTimeout(){const el=document.getElementById('connSub');if(el&&!window.jukenRxBytes)el.innerText='LIVE DIMINTA • BELUM ADA DATA RX ECU';}
function btHandshakeTimeout(cmd){const el=document.getElementById('connSub');if(el)el.innerText='JUKEN INIT TIMEOUT • '+String(cmd||'');document.getElementById('status').innerText='ERROR';}
function btDisconnected(){document.getElementById('connTitle').innerText='BELUM TERHUBUNG';document.getElementById('connSub').innerText='Scan & pairing ECU JUKEN via Bluetooth Classic';document.getElementById('status').innerText='OFFLINE'}
function btError(e){document.getElementById('connSub').innerText=e;document.getElementById('status').innerText='ERROR'}
function btDiscoveryDone(){}
let ecuRxBuffer='';
function btRaw(s){
  const rawEl=document.getElementById('raw');
  if(rawEl) rawEl.textContent=(s+'\n'+rawEl.textContent).slice(0,5000);
  ecuRxBuffer += String(s||'');
  parseLive(ecuRxBuffer);
}
function btHex(s){
  const el=document.getElementById('raw');
  if(el)el.textContent=('[HEX] '+s+'\n'+el.textContent).slice(0,5000);
}
function tpsRawToPercent(raw){
  const v=Math.trunc(Number(raw));
  if(!Number.isFinite(v) || v<0) return null;
  if(v===0) return 0;
  if(v===1) return 5;
  if(v>=2 && v<=19) return Math.max(0,Math.min(100,v*5-5));
  return 100;
}
function parseLive(s){
  // Parser dibuat toleran untuk dua layout A603 yang ditemukan pada data JUKEN:
  // layout lapangan yang terlihat di unit user (AFR tepat setelah EOT) dan
  // layout referensi yang menaruh Fuel Raw sebelum AFR. Kita pilih AFR yang
  // masuk akal (8..25) dan tetap mempertahankan TPS/RPM/BAT dari field yang sama.
  const text=String(s||'').replace(/\x00/g,'');
  const re=/A603;([^\r\n]*?)(?=(?:A603;)|[\r\n]|$)/gi;
  let m,lastEnd=0,got=false;
  while((m=re.exec(text))!==null){
    const parts=m[1].split(';');
    if(parts.length<13) continue;
    const num=(idx)=>{const v=Number(parts[idx]);return Number.isFinite(v)?v:null};
    const int=(idx)=>{const v=num(idx);return v==null?null:Math.trunc(v)};
    const tpsRaw=int(0), bat=num(1), rpm=int(3), eotRaw=num(4);
    const afrA=num(5), afrB=num(6);
    const afr=afrA!=null && afrA>=8 && afrA<=25 ? afrA : afrB;
    const base=num(7), inj=num(8), ignRaw=num(9), mapRaw=num(10);
    const iatRaw=num(12); // unit yang direkam user menunjukkan IAT di token terakhir
    if(rpm==null || tpsRaw==null || afr==null || bat==null) continue;
    // Captured JUKEN5++ Beat ECU sends TPS directly as 0..100 in A603.
    // For legacy/raw profiles, fall back to the old compact conversion only when
    // the value is outside the normal percentage range. Do not transform 1..19
    // for the verified percent-profile ECU.
    const identity=String(window.jukenEcuIdentity||'').toUpperCase();
    const percentProfile=identity.includes('JUKEN5') || identity.includes('JUKEN5++') || identity.includes('BEATFI');
    const t=percentProfile ? Math.max(0,Math.min(100,tpsRaw)) : (tpsRaw<=100 ? tpsRaw : tpsRawToPercent(tpsRaw));
    if(t==null || !Number.isFinite(t)) continue;
    const e=eotRaw==null?null:eotRaw/10;
    const it=iatRaw==null?null:iatRaw/10;
    const ign=ignRaw==null?null:ignRaw/10;
    active.rpm=rpm; active.tps=t;
    const st=document.getElementById('status'); if(st)st.innerText='LIVE • RX A603';
    const cs=document.getElementById('connSub'); if(cs)cs.innerText='JUKEN LIVE • DATA MASUK';
    applyCorrection(rpm,t,afr);
    setLive(rpm,t,afr,bat,e,it);
    window.jukenLiveLast={rpm,tps:t,tpsRaw,afr,bat,eot:e,iat:it,base,inj,ign,map:mapRaw,raw:'A603;'+m[1]};
    got=true;
    lastEnd=re.lastIndex;
  }
  if(lastEnd>0) ecuRxBuffer=text.slice(lastEnd); else ecuRxBuffer=text;
  if(ecuRxBuffer.length>8192) ecuRxBuffer=ecuRxBuffer.slice(-4096);
  return got;
}
const afrHistory=[];
const HISTORY_MAX=90;
function pushAfrHistory(r,a,target){if(r==null||a==null||target==null)return;afrHistory.push({t:Date.now(),afr:Number(a),target:Number(target),rpm:Number(r)});if(afrHistory.length>HISTORY_MAX)afrHistory.splice(0,afrHistory.length-HISTORY_MAX);drawAfrChart()}
function setLive(r,t,a,b,e,i){const set=(id,v)=>{const el=document.getElementById(id);if(el)el.innerText=v==null?'—':v};const target=r==null?null:getTarget(r);set('rpm',r);set('tps',t);set('afr',a);set('target',target==null?'—':target.toFixed(1));set('srpm',r==null?null:Math.round(r/250)*250);set('stps',t);set('grpm',r);set('gtps',t);set('gafr',a);set('gTarget',target==null?null:target.toFixed(1));set('gbat',b==null?null:Number(b).toFixed(1)+' V');set('geot',e==null?null:Number(e).toFixed(1)+' °C');set('giat',i==null?null:Number(i).toFixed(1)+' °C');set('mrpm',r);set('mtps',t);set('mafr',a);set('mbat',b);set('meot',e);set('miat',i);pushAfrHistory(r,a,target);updateBaseCell()}
function drawAfrChart(){const c=document.getElementById('chart');if(!c)return;const w=c.clientWidth||340,h=c.clientHeight||300,dpr=window.devicePixelRatio||1;c.width=Math.max(1,Math.floor(w*dpr));c.height=Math.max(1,Math.floor(h*dpr));const x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);x.fillStyle='#061019';x.fillRect(0,0,w,h);const L=34,R=w-10,T=18,B=h-38;const min=10,max=16;const X=n=>L+(n/Math.max(1,HISTORY_MAX-1))*(R-L);const Y=v=>B-(Math.max(min,Math.min(max,v))-min)/(max-min)*(B-T);x.font='10px Arial';x.textAlign='right';x.strokeStyle='rgba(48,92,110,.34)';x.lineWidth=1;for(let v=10;v<=16;v++){const y=Y(v);x.beginPath();x.moveTo(L,y);x.lineTo(R,y);x.stroke();x.fillStyle='#8ea5b3';x.fillText(v,L-7,y+3)}x.textAlign='center';for(let k=0;k<=6;k++){const xx=L+k*(R-L)/6;x.beginPath();x.moveTo(xx,T);x.lineTo(xx,B);x.stroke();x.fillStyle='#718b99';x.fillText(String(k*5),xx,B+16)}x.strokeStyle='#8da7b5';x.beginPath();x.moveTo(L,T);x.lineTo(L,B);x.lineTo(R,B);x.stroke();const draw=(key,color)=>{if(!afrHistory.length)return;x.strokeStyle=color;x.lineWidth=2.2;x.lineJoin='round';x.lineCap='round';x.beginPath();afrHistory.forEach((p,n)=>{const q=[X(n),Y(p[key])];n?x.lineTo(q[0],q[1]):x.moveTo(q[0],q[1])});x.stroke()};draw('target','#168cff');draw('afr','#ff1744');x.fillStyle='#9db2bf';x.font='9px Arial';x.textAlign='left';x.fillText('AFR',L,T-6);x.textAlign='center';x.fillText('Waktu (detik)',(L+R)/2,h-8);x.textAlign='left'}

let tuneAccum={};
const ECU_TPS=[0,2,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,100];
const AUTO_MIN_RPM=1500;
const AUTO_MAX_RPM=16000;
const AUTO_MIN_TPS=2;
const AUTO_MAX_TPS=100;
const AUTO_DEADBAND=0.15;
const AUTO_MAX_STEP=5.0;
const AUTO_WRITE_EVERY=8;
function getTuneKey(r,t){return String(r)+'@'+String(t)}
function getTarget(r){if(r<5000)return targets.low;if(r<10000)return targets.mid;return targets.high}
function applyCorrection(r,t,a){
  if(!live||r==null||t==null||a==null||!isFinite(a))return;
  if(r<AUTO_MIN_RPM||r>AUTO_MAX_RPM||t==null||t<AUTO_MIN_TPS||t>AUTO_MAX_TPS)return;
  const target=getTarget(r); if(!isFinite(target)||target<=0)return;
  const err=(a-target)/target*100;
  if(Math.abs(err)<AUTO_DEADBAND)return;
  const step=Math.max(-AUTO_MAX_STEP,Math.min(AUTO_MAX_STEP,err));
  const rr=RPM.reduce((p,x)=>Math.abs(x-r)<Math.abs(p-r)?x:p,RPM[0]);
  const tt=TPS.reduce((p,x)=>Math.abs(x-t)<Math.abs(p-t)?x:p,TPS[0]);
  const key=getTuneKey(rr,tt);
  if(!tuneAccum[key])tuneAccum[key]={sum:0,count:0,last:0};
  tuneAccum[key].sum+=step; tuneAccum[key].count++;
  const avg=tuneAccum[key].sum/tuneAccum[key].count;
  const next=Math.max(-25,Math.min(25,avg));
  corr[tt][rr]=Math.round(next*10)/10;
  active={rpm:r,tps:t};
  document.getElementById('corr').innerText=(next>=0?'+':'')+next.toFixed(1)+'%';
  draw3d();renderFuel();renderPos();updateBaseCell();
  // Actual ECU write is handled by the native bridge after a small sample
  // count so a single noisy AFR reading cannot change the ECU map.
  // Native ECU writes are intentionally disabled until the original JUKEN
  // Fuel Correction write frame is captured and verified. This prevents
  // sending an invented map command to a real ECU.

}
function startLive(){
  live=true; tuneAccum={};
  document.getElementById('status').innerText='LIVE';
  try{AndroidBT.startLive()}catch(e){}
  draw3d();
}
function stopLive(){
  live=false;
  document.getElementById('status').innerText='PAUSE';
  try{AndroidBT.stopLive()}catch(e){}
}
function renderFuel(){let h='<tr><th>TPS\\RPM</th>'+RPM.map(r=>'<th>'+r+'</th>').join('')+'</tr>';TPS.forEach(t=>{h+='<tr><th>'+t+'%</th>'+RPM.map(r=>{let ac=active.rpm!=null&&Math.abs(r-active.rpm)<=500&&active.tps!=null&&Math.abs(t-active.tps)<=5?' activeCell':'';return '<td class="zero'+ac+'">'+(corr[t][r]||0).toFixed(1)+'</td>'}).join('')+'</tr>'});document.getElementById('fuelMap').innerHTML=h}
function renderPos(){let h='<tr><th>TPS\\RPM</th>'+RPM.map(r=>'<th>'+r/1000+'</th>').join('')+'</tr>';TPS.forEach(t=>{h+='<tr><th>'+t+'%</th>'+RPM.map(r=>{let ac=active.rpm!=null&&Math.abs(r-active.rpm)<=500&&active.tps!=null&&Math.abs(t-active.tps)<=5?' activeCell':'';return '<td class="zero'+ac+'">'+(corr[t][r]||0).toFixed(0)+'</td>'}).join('')+'</tr>'});document.getElementById('posMap').innerHTML=h}
function corrColor(v){const z=Math.max(-25,Math.min(25,v));const stops=[[0,[22,77,255]],[.25,[0,191,255]],[.5,[24,212,138]],[.75,[255,229,28]],[1,[255,45,34]]];let p=(z+25)/50;for(let i=0;i<stops.length-1;i++){if(p<=stops[i+1][0]){const a=stops[i],b=stops[i+1],q=(p-a[0])/(b[0]-a[0]);return 'rgb('+Math.round(a[1][0]+(b[1][0]-a[1][0])*q)+','+Math.round(a[1][1]+(b[1][1]-a[1][1])*q)+','+Math.round(a[1][2]+(b[1][2]-a[1][2])*q)+')'}}return 'rgb(255,45,34)'}
function draw3d(){
  const c=document.getElementById('c3d'); if(!c)return;
  const w=c.clientWidth||340,h=c.clientHeight||330,dpr=window.devicePixelRatio||1;
  c.width=Math.max(1,Math.floor(w*dpr));c.height=Math.max(1,Math.floor(h*dpr));
  const x=c.getContext('2d');x.setTransform(dpr,0,0,dpr,0,0);x.clearRect(0,0,w,h);
  const bg=x.createRadialGradient(w*.52,h*.25,5,w*.52,h*.65,Math.max(w,h));bg.addColorStop(0,'#0b2432');bg.addColorStop(.55,'#06131d');bg.addColorStop(1,'#02080d');x.fillStyle=bg;x.fillRect(0,0,w,h);
  const left=38,right=w-42,top=32,bottom=h-48,ox=(left+right)*.52,oy=bottom-4,sx=Math.min(w*.67,238),sy=Math.min(w*.25,92),sz=Math.min(h*.43,128),maxZ=25;
  const project=(i,j,v)=>{const xx=i/(RPM.length-1),yy=j/(TPS.length-1),zz=Math.max(-maxZ,Math.min(maxZ,v))/maxZ;return [ox+(xx-.5)*sx-(yy-.5)*sy,oy+xx*14+(yy-.5)*sy-zz*sz]};
  const line=(a,b,col,lw=1)=>{x.strokeStyle=col;x.lineWidth=lw;x.beginPath();x.moveTo(a[0],a[1]);x.lineTo(b[0],b[1]);x.stroke()};
  // 3D box: floor + rear/side walls.
  const p00=project(0,0,0),p10=project(RPM.length-1,0,0),p11=project(RPM.length-1,TPS.length-1,0),p01=project(0,TPS.length-1,0);
  x.fillStyle='rgba(3,18,27,.82)';x.beginPath();x.moveTo(...p00);x.lineTo(...p10);x.lineTo(...p11);x.lineTo(...p01);x.closePath();x.fill();
  x.strokeStyle='rgba(111,162,182,.42)';x.lineWidth=1.1;x.beginPath();x.moveTo(...p00);x.lineTo(...p10);x.lineTo(...p11);x.lineTo(...p01);x.closePath();x.stroke();
  // Perspective grid.
  x.lineWidth=.75;
  for(let j=0;j<TPS.length;j++){const a=project(0,j,0),b=project(RPM.length-1,j,0);line(a,b,'rgba(76,128,149,.34)')}
  for(let i=0;i<RPM.length;i++){const a=project(i,0,0),b=project(i,TPS.length-1,0);line(a,b,'rgba(76,128,149,.34)')}
  // Correction surface; Base Map remains the reference only, correction is the Z value.
  for(let j=TPS.length-2;j>=0;j--)for(let i=RPM.length-2;i>=0;i--){const v00=corr[TPS[j]][RPM[i]]||0,v10=corr[TPS[j]][RPM[i+1]]||0,v11=corr[TPS[j+1]][RPM[i+1]]||0,v01=corr[TPS[j+1]][RPM[i]]||0;const a=project(i,j,v00),b=project(i+1,j,v10),cc=project(i+1,j+1,v11),d=project(i,j+1,v01),avg=(v00+v10+v11+v01)/4; x.beginPath();x.moveTo(...a);x.lineTo(...b);x.lineTo(...cc);x.lineTo(...d);x.closePath();x.fillStyle=corrColor(avg);x.fill();x.strokeStyle='rgba(0,9,14,.68)';x.lineWidth=.45;x.stroke()}
  // Vertical guide walls make the graph read like a real 3D cube.
  const zTop=project(0,0,maxZ),zBot=project(0,0,-maxZ);line(p00,zTop,'rgba(224,244,255,.7)',1.2);line(p00,zBot,'rgba(224,244,255,.25)');
  for(let z=-25;z<=25;z+=5){const q=project(0,0,z);line([q[0]-5,q[1]],[q[0],q[1]],'rgba(165,198,212,.42)');x.fillStyle='#9db2bf';x.font='8px Arial';x.textAlign='right';x.fillText((z>0?'+':'')+z+'%',q[0]-7,q[1]+3)}
  // Axis labels and ticks.
  x.fillStyle='#d5e7ef';x.font='10px Arial';x.textAlign='left';x.fillText('Fuel Correction (%)',8,16);x.fillStyle='#9eb6c3';x.font='9px Arial';
  x.textAlign='center';[0,4,8,12,16].forEach(v=>{const idx=Math.max(0,Math.min(RPM.length-1,Math.round((v*1000-1000)/250)));const q=project(idx,0,0);x.fillText(v+'k',q[0],q[1]+17)});
  [0,20,40,60,80,100].forEach(v=>{const idx=TPS.indexOf(v);if(idx>=0){const q=project(0,idx,0);x.fillText(String(v),q[0]-4,q[1]+13)}});
  x.fillStyle='#b8ccd5';x.font='bold 9px Arial';x.fillText('RPM ×1000',right-8,bottom+31);x.fillText('TPS (%)',left+8,bottom+2);
  // Color scale.
  const gx=w-18,gy=36,gh=Math.min(132,h*.42),grad=x.createLinearGradient(0,gy+gh,0,gy);grad.addColorStop(0,'#164dff');grad.addColorStop(.25,'#00bfff');grad.addColorStop(.5,'#18d48a');grad.addColorStop(.75,'#ffe51c');grad.addColorStop(1,'#ff2d22');x.fillStyle=grad;x.fillRect(gx,gy,7,gh);x.fillStyle='#dcefff';x.font='8px Arial';x.textAlign='left';x.fillText('+25%',gx-5,gy-7);x.fillText('0%',gx+10,gy+gh/2+3);x.fillText('-25%',gx-5,gy+gh+12);
  // Active cell marker.
  if(active.rpm!=null&&active.tps!=null){let ii=RPM.reduce((p,v,k)=>Math.abs(v-active.rpm)<Math.abs(RPM[p]-active.rpm)?k:p,0),jj=TPS.reduce((p,v,k)=>Math.abs(v-active.tps)<Math.abs(TPS[p]-active.tps)?k:p,0),vv=corr[TPS[jj]][RPM[ii]]||0,q=project(ii,jj,vv);x.fillStyle='#fff';x.shadowBlur=12;x.shadowColor='#fff';x.beginPath();x.arc(q[0],q[1],4,0,Math.PI*2);x.fill();x.shadowBlur=0;line(q,[q[0],q[1]+22],'#fff',1.4);const bw=76,bh=29,bx=Math.max(7,Math.min(w-bw-7,q[0]-bw/2)),by=Math.max(28,q[1]-43);x.fillStyle='#06111a';x.strokeStyle='#fff';x.lineWidth=1;x.beginPath();x.roundRect(bx,by,bw,bh,8);x.fill();x.stroke();x.fillStyle='#fff';x.font='bold 12px Arial';x.textAlign='center';x.fillText((vv>=0?'+':'')+vv.toFixed(1)+'%',bx+bw/2,by+19);x.textAlign='left'}
}
function toggleAutoSetting(){const e=document.getElementById('autoSetting');e.style.display=e.style.display==='none'?'block':'none';loadTargetInputs()}
function loadTargetInputs(){document.getElementById('afrLow').value=targets.low;document.getElementById('afrMid').value=targets.mid;document.getElementById('afrHigh').value=targets.high}
function saveTargets(){targets.low=clampNum(document.getElementById('afrLow').value,8,20,13.2);targets.mid=clampNum(document.getElementById('afrMid').value,8,20,13.2);targets.high=clampNum(document.getElementById('afrHigh').value,8,20,13.2);try{localStorage.setItem('rnautomap_targets',JSON.stringify(targets));localStorage.setItem('rnautomap_target_afr',JSON.stringify({low:targets.low,mid:targets.mid,high:targets.high,savedAt:Date.now()}))}catch(e){}loadTargetInputs();setLive(active.rpm,null,null,null,null,null);alert('Target AFR Low/Mid/High tersimpan.')}
function clampNum(v,min,max,f){let n=parseFloat(v);return isFinite(n)?Math.max(min,Math.min(max,n)):f}
function acceptCalculatorData(d){if(!d||!d.rpmCols||!d.fuelMap||!d.ignMap){document.getElementById('baseStatus').innerText='BELUM ADA MAP';document.getElementById('baseSpec').innerText='Tekan HITUNG PETA di Kalkulator Map, lalu sinkronkan.';return false}baseData=d;try{localStorage.setItem('rnautomap_base_map',JSON.stringify(d))}catch(e){}document.getElementById('baseStatus').innerText='TERSIMPAN • '+d.rpmCols.length+' KOLOM RPM';document.getElementById('baseSpec').innerText='RPM '+d.rpmCols[0]+'–'+d.rpmCols[d.rpmCols.length-1]+' • TPS 0–100%';document.getElementById('ignStatus').innerText='TERSIMPAN • '+d.rpmCols.length+' KOLOM RPM';document.getElementById('ignSpec').innerText='Base Ignition dari hasil kalkulator';if(d.spec){if(isFinite(d.spec.afrLow))targets.low=d.spec.afrLow;if(isFinite(d.spec.afrMid))targets.mid=d.spec.afrMid;if(isFinite(d.spec.afrTop))targets.high=d.spec.afrTop;try{localStorage.setItem('rnautomap_targets',JSON.stringify(targets))}catch(e){}}updateBaseCell();return true}
window.addEventListener('message',e=>{const m=e&&e.data;if(!m||m.type!=='rnautomap-calculator-data')return;try{const d=typeof m.json==='string'?JSON.parse(m.json):m.data;if(acceptCalculatorData(d)){document.getElementById('baseSpec').innerText='Sinkron berhasil • RPM '+d.rpmCols[0]+'–'+d.rpmCols[d.rpmCols.length-1]+' • TPS 0–100%';}}catch(err){document.getElementById('baseSpec').innerText='Data kalkulator tidak valid: '+err}});
function requestCalculatorSync(){const frame=document.getElementById('calcFrame');if(!frame||!frame.contentWindow)return false;let got=false;try{if(typeof frame.contentWindow.getRNAutoMapData==='function'){const d=frame.contentWindow.getRNAutoMapData();if(d&&acceptCalculatorData(d))got=true;}}catch(e){}try{frame.contentWindow.postMessage({type:'rnautomap-request-calculator-data'},'*')}catch(e){}return got}
function syncBaseFromCalculator(){const frame=document.getElementById('calcFrame');if(!frame)return;document.getElementById('baseStatus').innerText='MENGAMBIL DATA...';document.getElementById('ignStatus').innerText='MENGAMBIL DATA...';const got=requestCalculatorSync();setTimeout(()=>{if(baseData){document.getElementById('baseSpec').innerText='Sinkron berhasil • RPM '+baseData.rpmCols[0]+'–'+baseData.rpmCols[baseData.rpmCols.length-1]+' • TPS 0–100%';document.getElementById('ignSpec').innerText='Base Ignition tersimpan dari Kalkulator Map';return}document.getElementById('baseStatus').innerText='BELUM ADA MAP';document.getElementById('ignStatus').innerText='BELUM ADA MAP';document.getElementById('baseSpec').innerText='Tekan HITUNG PETA di Kalkulator Map, lalu SINKRONKAN lagi.';document.getElementById('ignSpec').innerText='Kalkulator belum mengirim Base Ignition.'},500)}
function nearestKey(obj,v){const ks=Object.keys(obj||{}).map(Number);if(!ks.length)return null;return ks.reduce((p,x)=>Math.abs(x-v)<Math.abs(p-v)?x:p,ks[0])}
function updateBaseCell(){if(!baseData||active.rpm==null||active.tps==null){document.getElementById('baseFuelCell').innerText='—';document.getElementById('baseIgnCell').innerText='—';return}const r=nearestKey(baseData.fuelMap,active.tps);const rr=nearestKey(baseData.fuelMap[r],active.rpm);const fuel=baseData.fuelMap[r][rr];const ign=baseData.ignMap[r][rr];document.getElementById('baseFuelCell').innerText=(isFinite(fuel)?fuel.toFixed(2)+' ms':'—');document.getElementById('baseIgnCell').innerText=(isFinite(ign)?ign.toFixed(1)+'°':'—')}
const calcFrameEl=document.getElementById('calcFrame');if(calcFrameEl)calcFrameEl.addEventListener('load',()=>setTimeout(requestCalculatorSync,150));
window.addEventListener('resize',()=>{draw3d();drawAfrChart()});
try{const bd=JSON.parse(localStorage.getItem('rnautomap_base_map')||'null');if(bd)acceptCalculatorData(bd)}catch(e){}
renderFuel();renderPos();draw3d();drawAfrChart();loadTargetInputs();

package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.UUID;
import java.lang.reflect.Method;

public class MainActivity extends Activity {
  WebView web; BluetoothAdapter bt; BluetoothSocket socket; OutputStream out; InputStream in; ExecutorService io=Executors.newSingleThreadExecutor(); ExecutorService readExec=Executors.newSingleThreadExecutor(); ScheduledExecutorService livePoll=Executors.newSingleThreadScheduledExecutor(); final Object txLock=new Object();
  final Object mapLock=new Object();
  static final int[] ECU_TPS={0,2,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,100};
  static final int ECU_RPM_START=1000, ECU_RPM_STEP=250, ECU_COLS=61, ECU_ROWS=21;
  volatile long rxBytes=0;
  volatile long lastRxAt=0;
  boolean liveRetryScheduled=false;
  volatile boolean jukenHandshakeStarted=false;
  volatile boolean jukenIdentitySeen=false;
  volatile long liveStartedAt=0;
  volatile int handshakeStage=0;
  volatile int handshakeRetries=0;
  final ScheduledExecutorService protocolTimer=Executors.newSingleThreadScheduledExecutor();
  volatile long lastLiveFrameAt=0;
  int[][] fuelMap=new int[ECU_ROWS][ECU_COLS];
  boolean fuelMapReady=false, fuelMapReading=false; int fuelReadRow=0;
  float[][] fuelCorrection=new float[ECU_ROWS][ECU_COLS];
  static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  final Handler h=new Handler(Looper.getMainLooper());
  final Set<String> seen=new HashSet<>(); String pendingPairAddress=null;
  BroadcastReceiver receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){
    if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){ BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null) addDevice(d); }
    if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(i.getAction())) web.post(()->web.evaluateJavascript("window.btDiscoveryDone&&btDiscoveryDone()",null));
    if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(i.getAction())){
      BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
      int state=i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE,BluetoothDevice.ERROR);
      if(d!=null && state==BluetoothDevice.BOND_BONDING && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        h.post(()->web.evaluateJavascript("window.btPairingStarted&&btPairingStarted("+q(d.getAddress())+")",null));
      }
      if(d!=null && state==BluetoothDevice.BOND_BONDED && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        String addr=pendingPairAddress; pendingPairAddress=null;
        h.post(()->web.evaluateJavascript("window.btBonded&&btBonded("+q(addr)+")",null));
        h.postDelayed(()->MainActivity.this.connectInternal(addr),300);
      }
      if(d!=null && state==BluetoothDevice.BOND_NONE && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        pendingPairAddress=null; msg("Pairing Bluetooth JUKEN gagal / dibatalkan");
      }
    }
  }};
  @Override public void onCreate(Bundle b){super.onCreate(b); setupWeb(); requestBt(); IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED); if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_EXPORTED); else registerReceiver(receiver,f);}
  void setupWeb(){ web=new WebView(this); web.setBackgroundColor(0xff050b12); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowFileAccessFromFileURLs(true); web.getSettings().setAllowUniversalAccessFromFileURLs(true); web.addJavascriptInterface(new Bridge(),"AndroidBT"); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/app.html"); }
  void requestBt(){
    if(Build.VERSION.SDK_INT>=31){
      requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},41);
    }else if(Build.VERSION.SDK_INT>=23){
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},42);
    }
  }
  boolean ok(){
    if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
    if(Build.VERSION.SDK_INT>=23) return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    return true;
  }
  void addDevice(BluetoothDevice d){ if(!ok()) return; String name=d.getName(); if(name==null) name="(tanpa nama)"; String addr=d.getAddress(); if(seen.add(addr)){ String j=name.toUpperCase(Locale.US).contains("JUKEN")||name.toUpperCase(Locale.US).contains("BRT")?"true":"false"; String js="window.btFound&&btFound("+q(name)+","+q(addr)+","+j+")"; web.post(()->web.evaluateJavascript(js,null)); } }
  String q(String s){return "'"+s.replace("\\","\\\\").replace("\r","\\r").replace("\n","\\n").replace("\t","\\t").replace("'","\\'")+"'";}
  public class Bridge{
    @JavascriptInterface public void scan(){ if(!ok()){requestBt();return;} bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null){msg("Bluetooth tidak tersedia");return;} if(!bt.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),42);return;} seen.clear(); web.post(()->web.evaluateJavascript("window.btScanStarted&&btScanStarted()",null)); for(BluetoothDevice d:bt.getBondedDevices()) addDevice(d); bt.cancelDiscovery(); bt.startDiscovery(); }
    @JavascriptInterface public void connect(String addr){ if(!ok())return; pairThenConnect(addr); }
    @JavascriptInterface public void pairAndConnect(String addr){ if(!ok())return; pairThenConnect(addr); }
    @JavascriptInterface public void send(String s){sendRaw(s);}
    @JavascriptInterface public void startLive(){startJukenLivePolling();}
    @JavascriptInterface public void autoTuneCorrection(int rpm,int tps,float pct){applyAutoTuneCorrection(rpm,tps,pct);}
    @JavascriptInterface public void stopLive(){stopJukenLivePolling(); sendJuken("160B");}
    @JavascriptInterface public void disconnect(){close();}
    @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
  }
  void pairThenConnect(String addr){
    try{
      if(bt==null) bt=BluetoothAdapter.getDefaultAdapter();
      if(bt==null){ msg("Bluetooth tidak tersedia"); return; }
      BluetoothDevice d=bt.getRemoteDevice(addr);
      if(d.getBondState()==BluetoothDevice.BOND_BONDED){
        h.post(()->web.evaluateJavascript("window.btBonded&&btBonded("+q(addr)+")",null));
        connectInternal(addr);
        return;
      }
      pendingPairAddress=addr;
      h.post(()->web.evaluateJavascript("window.btPairingStarted&&btPairingStarted("+q(addr)+")",null));
      boolean started=d.createBond();
      if(!started){ pendingPairAddress=null; msg("Pairing JUKEN tidak dapat dimulai"); }
    }catch(Exception e){ pendingPairAddress=null; msg("Pairing JUKEN gagal: "+e.getMessage()); }
  }

  void connectInternal(String addr){
    io.submit(()->{
      try{
        if(bt==null) bt=BluetoothAdapter.getDefaultAdapter();
        if(bt==null){ msg("Bluetooth tidak tersedia"); return; }
        bt.cancelDiscovery();

        BluetoothDevice d=bt.getRemoteDevice(addr);
        String nm=d.getName()==null?"JUKEN":d.getName();
        if(d.getBondState()!=BluetoothDevice.BOND_BONDED){
          h.post(()->web.evaluateJavascript("window.btPairingNeeded&&btPairingNeeded("+q(addr)+")",null));
          return;
        }
        notifyConn("PAIRED ✓ • MEMBUKA RFCOMM JUKEN • "+nm);

        // Transport observed for JUKEN: Bluetooth Classic RFCOMM/SPP.
        // SPP UUID observed/used by the JUKEN transport:
        // 00001101-0000-1000-8000-00805F9B34FB.
        BluetoothSocket connected=null;
        StringBuilder errors=new StringBuilder();

        // Bond is complete before any JUKEN protocol traffic.
        // Standard SPP UUID first; captured Android stack also reported RFCOMM SCN 1.
        for(int attempt=1; attempt<=3 && connected==null; attempt++){
          notifyConn("JUKEN RFCOMM SPP • percobaan "+attempt+"/3");
          connected=trySocketOnce(d,SPP,true,errors);
          if(connected==null) try{Thread.sleep(250);}catch(InterruptedException ignored){}
        }
        if(connected==null) connected=tryChannel1(d,false,errors);

        if(connected==null){
          String detail=errors.length()>0?errors.toString():"tidak ada metode RFCOMM yang berhasil";
          throw new IOException("Koneksi JUKEN gagal: "+detail);
        }

        socket=connected;
        out=socket.getOutputStream();
        in=socket.getInputStream();

        h.post(()->web.evaluateJavascript("window.btSocketConnected&&btSocketConnected("+q(nm)+")",null));

        // IMPORTANT: reproduce the exact response-driven sequence observed from
        // the user's original JUKEN app. Do not jump directly to 160A.
        readExec.submit(MainActivity.this::readLoop);
        startJukenHandshakeExact();

      }catch(Exception e){
        h.post(()->web.evaluateJavascript("window.btError&&btError("+q(e.toString())+")",null));
        close();
      }
    });
  }

  BluetoothSocket trySocket(BluetoothDevice d, UUID uuid, boolean secure, StringBuilder errors){
    return trySocketOnce(d,uuid,secure,errors);
  }

  BluetoothSocket tryUuidSocket(BluetoothDevice d, UUID uuid, StringBuilder errors){
    BluetoothSocket s=trySocketOnce(d,uuid,true,errors);
    if(s==null) s=trySocketOnce(d,uuid,false,errors);
    return s;
  }

  BluetoothSocket trySocketOnce(BluetoothDevice d, UUID uuid, boolean secure, StringBuilder errors){
    BluetoothSocket s=null;
    try{
      bt.cancelDiscovery();
      s=secure?d.createRfcommSocketToServiceRecord(uuid):d.createInsecureRfcommSocketToServiceRecord(uuid);
      s.connect();
      return s;
    }catch(Exception e){
      if(s!=null) try{s.close();}catch(Exception ignored){}
      if(errors.length()<1800) errors.append("[UUID ").append(uuid).append(secure?" secure":" insecure").append("] ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append(" ");
      return null;
    }
  }

  BluetoothSocket tryChannel1(BluetoothDevice d, boolean insecure, StringBuilder errors){
    BluetoothSocket s=null;
    try{
      bt.cancelDiscovery();
      Method m=d.getClass().getMethod(insecure?"createInsecureRfcommSocket":"createRfcommSocket", int.class);
      s=(BluetoothSocket)m.invoke(d,1);
      s.connect();
      return s;
    }catch(Exception e){
      if(s!=null) try{s.close();}catch(Exception ignored){}
      if(errors.length()<1800) errors.append("[RFCOMM1 ").append(insecure?"insecure":"secure").append("] ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append(" ");
      return null;
    }
  }

  void notifyConn(String s){
    h.post(()->web.evaluateJavascript("window.btConnecting&&btConnecting("+q(s)+")",null));
  }

  void sendRaw(String s){
    synchronized(txLock){
      try{
        if(out!=null && socket!=null && socket.isConnected()){
          out.write(s.getBytes("US-ASCII"));
          out.flush();
        }
      }catch(Exception e){ }
    }
  }
  void sendJuken(String command){
    String c=command.endsWith("\r\n")?command:command+"\r\n";
    sendRaw(c);
  }

  void startJukenHandshake(){ startJukenHandshakeExact(); }

  // Exact sequence captured from the original JUKEN application for the
  // user's ECU profile:
  // 160B -> 1A00 -> 1606 -> 9606 -> 1616 -> 9616 -> 1500 -> 9500
  // -> 1B00 -> 1b01 -> 160A -> 1A00 -> A603...
  //
  // We only advance when the expected response arrives. This avoids the
  // previous failure mode where 160A was sent before the ECU was initialized.
  void startJukenHandshakeExact(){
    if(socket==null || !socket.isConnected()) return;
    jukenHandshakeStarted=true;
    jukenIdentitySeen=false;
    handshakeStage=1;
    handshakeRetries=0;
    liveStartedAt=0;
    lastLiveFrameAt=0;
    h.post(()->web.evaluateJavascript("window.btMapStatus&&btMapStatus('JUKEN INIT • 160B')",null));
    sendJuken("160B");
    scheduleHandshakeRetry(1, "160B");
  }

  void scheduleHandshakeRetry(final int stage, final String command){
    try{ protocolTimer.schedule(()->{
      if(socket==null || !socket.isConnected() || handshakeStage!=stage) return;
      if(handshakeRetries>=3){
        h.post(()->web.evaluateJavascript("window.btHandshakeTimeout&&btHandshakeTimeout("+q(command)+")",null));
        return;
      }
      handshakeRetries++;
      sendJuken(command);
      scheduleHandshakeRetry(stage,command);
    },1200,TimeUnit.MILLISECONDS); }catch(Exception ignored){}
  }

  void advanceHandshake(int nextStage, String command, String status){
    handshakeStage=nextStage;
    handshakeRetries=0;
    h.post(()->web.evaluateJavascript("window.btMapStatus&&btMapStatus("+q(status)+")",null));
    sendJuken(command);
    scheduleHandshakeRetry(nextStage,command);
  }

  void readFuelMapThenStartLive(){
    synchronized(mapLock){
      fuelMapReading=true; fuelMapReady=false; fuelReadRow=0;
    }
    sendJuken("1602;2;0");
    // If an ECU/firmware does not implement the map read, never leave the user
    // without live data. Fall back after a bounded timeout.
    h.postDelayed(()->{
      boolean still; synchronized(mapLock){still=fuelMapReading;}
      if(still){
        synchronized(mapLock){fuelMapReading=false;}
        web.post(()->web.evaluateJavascript("window.btMapStatus&&btMapStatus('MAP READ TIMEOUT • SIAP LIVE')",null));
      }
    },7000);
  }

  void handleNativeLine(String line){
    String t=line.trim();
    String lower=t.toLowerCase(Locale.US);

    // Verified sequence observed from the original JUKEN app on the user's ECU:
    // 1606 -> 9606 -> 1616 -> 9616(identity) -> 1500 -> 9500 -> 1B00 -> 1b01 -> 160A -> 1A00.
    // We use the response-driven sequence so LIVE is not started before the ECU is ready.
    if(lower.equals("1a00") || lower.startsWith("1a00;")){
      h.post(()->web.evaluateJavascript("window.btLiveAck&&btLiveAck()",null));
      if(handshakeStage==1){
        advanceHandshake(2,"1606","JUKEN INIT • 1606");
      }
      return;
    }
    if(lower.startsWith("9606;")){
      if(handshakeStage==2) advanceHandshake(3,"1616","JUKEN INIT • 1616");
      return;
    }
    if(lower.startsWith("9616;")){
      String[] p=t.split(";",-1);
      String identity=p.length>1?t.substring(t.indexOf(';')+1):"";
      jukenIdentitySeen=true;
      h.post(()->web.evaluateJavascript("window.btEcuIdentity&&btEcuIdentity("+q(identity)+")",null));
      if(handshakeStage==3) advanceHandshake(4,"1500","ECU • "+identity);
      return;
    }
    if(lower.startsWith("9500;")){
      if(handshakeStage==4) advanceHandshake(5,"1B00","JUKEN INIT • 1B00");
      return;
    }
    if(lower.equals("1b01") || lower.startsWith("1b01;")){
      if(handshakeStage==5){
        handshakeStage=6;
        handshakeRetries=0;
        startJukenLivePolling();
      }
      return;
    }
    if(t.startsWith("9602;")){
      String[] p=t.split(";");
      if(p.length>=62){
        int row; synchronized(mapLock){row=fuelReadRow;}
        int[] vals=new int[ECU_COLS]; boolean ok=true;
        for(int i=0;i<ECU_COLS;i++){
          try{vals[i]=Math.round(Float.parseFloat(p[i+1]));}catch(Exception e){ok=false;break;}
        }
        if(ok && row>=0 && row<ECU_ROWS){
          synchronized(mapLock){
            fuelMap[row]=vals;
            fuelReadRow++;
            if(fuelReadRow>=ECU_ROWS){fuelMapReading=false;fuelMapReady=true;}
          }
          boolean done; synchronized(mapLock){done=!fuelMapReading && fuelMapReady;}
          if(done){
            web.post(()->web.evaluateJavascript("window.btMapStatus&&btMapStatus('FUEL MAP ECU TERBACA 21×61 • SIAP LIVE')",null));
          }else{
            int next; synchronized(mapLock){next=fuelReadRow;}
            sendJuken("1602;2;"+next);
          }
        }
      }
      return;
    }
  }

  int nearestEcuRow(int tps){
    int best=0,bestDiff=Integer.MAX_VALUE;
    for(int i=0;i<ECU_TPS.length;i++){int d=Math.abs(ECU_TPS[i]-tps);if(d<bestDiff){bestDiff=d;best=i;}}
    return best;
  }
  int nearestEcuCol(int rpm){
    int c=Math.round((rpm-ECU_RPM_START)/(float)ECU_RPM_STEP);
    return Math.max(0,Math.min(ECU_COLS-1,c));
  }
  void applyAutoTuneCorrection(int rpm,int tps,float pct){
    // Reserved for the verified JUKEN Fuel Correction write protocol.
    // Do not send a guessed command to the ECU.
  }
  void startJukenLivePolling(){
    if(socket==null || !socket.isConnected()) return;
    // For the verified ECU profile, LIVE must begin only after 1b01.
    if(jukenHandshakeStarted && handshakeStage<5) return;
    if(liveStartedAt>0) return;
    stopJukenLivePolling();
    liveRetryScheduled=false;
    liveStartedAt=System.currentTimeMillis();
    lastLiveFrameAt=0;
    h.post(()->web.evaluateJavascript("window.btLiveStarted&&btLiveStarted()",null));
    synchronized(txLock){
      try{out.write("160A\r\n".getBytes("US-ASCII"));out.flush();}catch(Exception ignored){}
    }
    h.postDelayed(()->{
      if(socket!=null && socket.isConnected() && lastLiveFrameAt < liveStartedAt && !liveRetryScheduled){
        liveRetryScheduled=true;
        sendJuken("160A");
      }
    },1700);
    h.postDelayed(()->{
      if(socket!=null && socket.isConnected() && lastLiveFrameAt < liveStartedAt){
        web.post(()->web.evaluateJavascript("window.btLiveTimeout&&btLiveTimeout()",null));
      }
    },3000);
  }
  void stopJukenLivePolling(){try{livePoll.shutdownNow();}catch(Exception e){} livePoll=Executors.newSingleThreadScheduledExecutor();}
  void readLoop(){
    byte[] buf=new byte[4096];
    StringBuilder nativeBuf=new StringBuilder();
    try{
      int n;
      while(socket!=null && in!=null){
        n=in.read(buf);
        if(n<0) break;
        if(n==0) continue;
        final byte[] packet=Arrays.copyOf(buf,n);
        rxBytes += n;
        lastRxAt = System.currentTimeMillis();
        final long rxNow=rxBytes;
        h.post(()->web.evaluateJavascript("window.btComm&&btComm("+rxNow+")",null));
        final String raw=new String(packet,"US-ASCII");
        final String hex=toHex(packet);
        if(raw.toLowerCase(Locale.US).contains("a603;")) lastLiveFrameAt=System.currentTimeMillis();
        nativeBuf.append(raw);
        int nl;
        while((nl=nativeBuf.indexOf("\n"))>=0){
          String line=nativeBuf.substring(0,nl);
          nativeBuf.delete(0,nl+1);
          handleNativeLine(line);
        }
        // Some adapters deliver a single complete response without CRLF.
        // Map responses are identifiable by their 9602 prefix and 61 values.
        int idx=nativeBuf.indexOf("9602;");
        if(idx>0)nativeBuf.delete(0,idx);
        h.post(()->web.evaluateJavascript("window.btRaw&&btRaw("+q(raw)+")",null));
        h.post(()->web.evaluateJavascript("window.btHex&&btHex("+q(hex)+")",null));
      }
    }catch(Exception e){ }
  }
  String toHex(byte[] b){
    StringBuilder z=new StringBuilder(b.length*3);
    for(byte v:b) z.append(String.format(Locale.US,"%02X ",v&0xFF));
    return z.toString().trim();
  }
  void closeSocketOnly(){
    try{if(socket!=null)socket.close();}catch(Exception e){}
    socket=null; out=null; in=null;
  }
  void close(){
    stopJukenLivePolling();
    sendJuken("160B");
    closeSocketOnly();
    h.post(()->web.evaluateJavascript("window.btDisconnected&&btDisconnected()",null));
  }
  void msg(String s){h.post(()->web.evaluateJavascript("window.btError&&btError("+q(s)+")",null));}
  @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception e){}close();io.shutdownNow();readExec.shutdownNow();livePoll.shutdownNow();protocolTimer.shutdownNow(); super.onDestroy();}
}

# RNAUTOMAP V11.1.18 — Graphics + Map Export

GitHub-ready Android source project.

- Keeps `MainActivity.java` unchanged from the provided V11.1.17 source.
- Refines responsive visual sizing for Live 3D and AFR chart on phones.
- Includes CSV export for calculator Base Map, Ignition Map, and Fuel Correction for manual transfer to the original Juken app.
- Auto Tune correction remains separate from Base Map.
- This app does not write map data to ECU. Verify map row/column formats before manual entry.

Build in GitHub Actions using `.github/workflows/build-apk.yml`.

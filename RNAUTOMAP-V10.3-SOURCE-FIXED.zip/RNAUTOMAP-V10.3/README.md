# RNAUTOMAP V10.3

Dashboard baru mengikuti referensi visual RNAUTOMAP/JUKEN.

## Perubahan utama
- UI dark/neon seperti mockup: Home, Auto Tuning Live, Grafik Live, Posisi Map, Fuel Correction, Monitor Data, Kalkulator, AI, Panduan, Bluetooth.
- Bluetooth Classic SPP: scan perangkat sekitar, prioritaskan nama JUKEN/BRT, pair jika belum dipair, lalu connect.
- Live data tetap `—` sebelum ECU benar-benar mengirim data.
- Fuel Correction mulai 0.0% di semua sel.
- Grid RPM 1.000–16.000 dan TPS 0–100%.
- 3D correction surface datar 0% sebelum auto tuning; berubah hanya saat data AFR nyata masuk dan Auto Tune aktif.
- Tidak ada command map-write ECU.
- Kalkulator mempertahankan input lama dan menambah selector Jenis Knalpot.
- RPM limit kalkulator default 16.000.

## Build
Buka Actions → Build RNAUTOMAP V10.3 → Run workflow / push ke branch `utama`.

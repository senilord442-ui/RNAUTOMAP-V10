package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQ_BT=77;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private InputStream in; private OutputStream out;
    private WebView web;
    private final Map<String,BluetoothDevice> discovered=new LinkedHashMap<>();
    private BroadcastReceiver receiver;
    private final AtomicBoolean connecting=new AtomicBoolean(false);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(3,12,20));
        web=new WebView(this);
        WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true); ws.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ openExternal(r.getUrl().toString()); return true; }
            @Override public boolean shouldOverrideUrlLoading(WebView v,String u){ openExternal(u); return true; }
        });
        web.addJavascriptInterface(new JsBridge(),"RNA");
        setContentView(web);
        adapter=BluetoothAdapter.getDefaultAdapter();
        registerBtReceiver();
        web.loadUrl("file:///android_asset/app.html");
        requestBtPermissionsIfNeeded();
    }
    private void openExternal(String u){ try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));}catch(Exception ignored){} }
    private boolean hasBtPerms(){
        if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }
    private void requestBtPermissionsIfNeeded(){
        if(hasBtPerms()) return;
        if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},REQ_BT);
    }
    private String esc(String s){return s==null?"":s.replace("\\","\\\\").replace("\"","\\\"").replace("\r","").replace("\n","");}
    private void js(String code){runOnUiThread(()->web.evaluateJavascript(code,null));}
    private void emitDevice(BluetoothDevice d, boolean paired){
        String name=""; String addr="";
        try{name=d.getName();}catch(Exception ignored){} try{addr=d.getAddress();}catch(Exception ignored){}
        if(name==null||name.trim().isEmpty()) name="Perangkat Bluetooth";
        final String n=name, a=addr;
        js("window.onBtDevice&&window.onBtDevice({name:\""+esc(n)+"\",address:\""+esc(a)+"\",paired:"+paired+"})");
    }
    private void scan(){
        if(!hasBtPerms()){requestBtPermissionsIfNeeded();return;}
        if(adapter==null){js("window.onBtStatus&&window.onBtStatus('Bluetooth tidak tersedia')");return;}
        if(!adapter.isEnabled()){js("window.onBtStatus&&window.onBtStatus('Nyalakan Bluetooth terlebih dahulu')");return;}
        discovered.clear();
        try{adapter.cancelDiscovery();}catch(Exception ignored){}
        try{
            for(BluetoothDevice d:adapter.getBondedDevices()) { discovered.put(d.getAddress(),d); emitDevice(d,true); }
        }catch(Exception ignored){}
        js("window.onBtScanStart&&window.onBtScanStart()");
        try{adapter.startDiscovery(); js("window.onBtStatus&&window.onBtStatus('Mencari perangkat Bluetooth di sekitar…')");}
        catch(Exception e){js("window.onBtStatus&&window.onBtStatus('Scan gagal: "+esc(e.getMessage())+"')");}
    }
    private void connect(String address){
        if(!hasBtPerms()){requestBtPermissionsIfNeeded();return;}
        BluetoothDevice d=discovered.get(address);
        if(d==null){try{d=adapter.getRemoteDevice(address);}catch(Exception e){js("window.onBtStatus&&window.onBtStatus('Perangkat tidak ditemukan')");return;}}
        final BluetoothDevice dev=d;
        try{adapter.cancelDiscovery();}catch(Exception ignored){}
        try{
            if(dev.getBondState()!=BluetoothDevice.BOND_BONDED){
                js("window.onBtStatus&&window.onBtStatus('Meminta pairing ke "+esc(dev.getName())+"…')");
                dev.createBond(); pendingAddress=address; return;
            }
        }catch(Exception e){js("window.onBtStatus&&window.onBtStatus('Pairing gagal: "+esc(e.getMessage())+"')");return;}
        connectBonded(dev);
    }
    private String pendingAddress=null;
    private void connectBonded(BluetoothDevice dev){
        if(!connecting.compareAndSet(false,true)) return;
        js("window.onBtStatus&&window.onBtStatus('Menghubungkan ke "+esc(dev.getName())+"…')");
        new Thread(()->{
            BluetoothSocket s=null;
            try{
                try{s=dev.createRfcommSocketToServiceRecord(SPP);s.connect();}
                catch(Exception first){try{if(s!=null)s.close();}catch(Exception ignored){} s=dev.createInsecureRfcommSocketToServiceRecord(SPP);s.connect();}
                socket=s; in=s.getInputStream(); out=s.getOutputStream();
                js("window.onBtConnected&&window.onBtConnected({name:\""+esc(dev.getName())+"\",address:\""+esc(dev.getAddress())+"\"})");
                // Known read/live request used by the reference JUKEN ecosystem; no map-write command is sent.
                sendRaw("160A\r\n");
                readLoop();
            }catch(Exception e){js("window.onBtStatus&&window.onBtStatus('Gagal konek: "+esc(e.getMessage())+"')"); closeBt();}
            finally{connecting.set(false);}
        }).start();
    }
    private void readLoop(){
        byte[] buf=new byte[4096]; StringBuilder acc=new StringBuilder();
        try{
            int n;
            while(socket!=null && socket.isConnected() && in!=null && (n=in.read(buf))>0){
                acc.append(new String(buf,0,n,StandardCharsets.US_ASCII));
                // Prefer newline-delimited frames, but also recover from fragmented packets containing A603.
                while(true){
                    int a=acc.toString().toLowerCase(Locale.US).indexOf("a603;");
                    if(a<0){ if(acc.length()>8192) acc.delete(0,acc.length()-2048); break; }
                    if(a>0) acc.delete(0,a);
                    int nl=acc.indexOf("\n");
                    if(nl<0){ if(acc.length()>4096){String chunk=acc.substring(0,Math.min(acc.length(),1024)); parseAndDispatch(chunk); acc.delete(0,Math.min(acc.length(),1024));} break; }
                    String frame=acc.substring(0,nl).replace("\r","").trim(); acc.delete(0,nl+1); if(!frame.isEmpty()) parseAndDispatch(frame);
                }
            }
        }catch(Exception e){js("window.onBtStatus&&window.onBtStatus('Koneksi terputus')");}
        finally{closeBt();}
    }
    private void parseAndDispatch(String raw){
        int idx=raw.toLowerCase(Locale.US).indexOf("a603;"); if(idx<0)return;
        String frame=raw.substring(idx); String[] p=frame.split(";");
        if(p.length<13)return;
        try{
            int tpsRaw=Integer.parseInt(p[1].trim()); int rpm=Integer.parseInt(p[4].trim());
            double bat=Double.parseDouble(p[2].trim()); double eot=Double.parseDouble(p[5].trim())/10.0; double afr=Double.parseDouble(p[7].trim());
            double inj=Double.parseDouble(p[9].trim()); double ign=Double.parseDouble(p[10].trim())/10.0; double mapRaw=Double.parseDouble(p[11].trim()); double iat=Double.parseDouble(p[12].trim())/10.0;
            int tps=tpsRaw<=0?0:(tpsRaw==1?5:(tpsRaw<=19?tpsRaw*5-5:100));
            int map=mappingMap(mapRaw*5.0/1023.0);
            String json=String.format(Locale.US,"{\"rpm\":%d,\"tps\":%d,\"afr\":%.3f,\"bat\":%.3f,\"eot\":%.2f,\"iat\":%.2f,\"inj\":%.2f,\"ign\":%.2f,\"map\":%d}",rpm,tps,afr,bat,eot,iat,inj,ign,map);
            js("window.onJukenLive&&window.onJukenLive("+json+")");
        }catch(Exception ignored){}
    }
    private int mappingMap(double v){ if(v<0.3)return (int)((100*v)/3.0); if(v<0.6)return (int)(((100*(v-0.3))/3.0)+10); if(v<1.1)return (int)(((100*(v-0.6))/5.0)+20); if(v<1.7)return (int)(((100*(v-1.1))/6.0)+30); if(v<2.2)return (int)(((100*(v-1.7))/5.0)+40); if(v<2.7)return (int)(((100*(v-2.2))/5.0)+50); if(v<3.3)return (int)(((100*(v-2.7))/6.0)+60); if(v<3.8)return (int)(((100*(v-3.3))/5.0)+70); if(v<4.4)return (int)(((100*(v-3.8))/6.0)+80); if(v<4.9)return (int)(((100*(v-4.4))/5.0)+90); return 100; }
    private synchronized void sendRaw(String s){try{if(out!=null){out.write(s.getBytes(StandardCharsets.US_ASCII));out.flush();}}catch(Exception ignored){}}
    private void closeBt(){try{if(socket!=null)socket.close();}catch(Exception ignored){} socket=null;in=null;out=null;js("window.onBtDisconnected&&window.onBtDisconnected()");}
    private void registerBtReceiver(){
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){String a=i.getAction(); if(BluetoothDevice.ACTION_FOUND.equals(a)){BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null){discovered.put(d.getAddress(),d); boolean paired=d.getBondState()==BluetoothDevice.BOND_BONDED; emitDevice(d,paired);}} else if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)){js("window.onBtScanDone&&window.onBtScanDone()");} else if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(a)){BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null && d.getAddress().equals(pendingAddress) && d.getBondState()==BluetoothDevice.BOND_BONDED){pendingAddress=null;connectBonded(d);}}}};
        IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_FOUND);f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);registerReceiver(receiver,f);
    }
    public class JsBridge{
        @JavascriptInterface public void scanBluetooth(){scan();}
        @JavascriptInterface public void connectBluetooth(String address){connect(address);}
        @JavascriptInterface public void disconnectBluetooth(){sendRaw("160B\r\n");closeBt();}
        @JavascriptInterface public void send(String command){sendRaw(command);}
        @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
    }
    @Override public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){} sendRaw("160B\r\n");closeBt();super.onDestroy();}
}

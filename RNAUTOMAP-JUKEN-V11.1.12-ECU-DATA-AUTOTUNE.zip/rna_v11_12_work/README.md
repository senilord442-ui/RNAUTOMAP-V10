# RNAUTOMAP JUKEN V11.1.12 — ECU DATA + AUTO TUNE ENGINE

Scope of this patch:
- Preserve the existing RNAutoMap UI/3D graphic and the existing calculator HTML.
- Fix the JUKEN A603 live-frame field indexing so RPM/TPS/AFR/etc. are read from the correct fields.
- Use the original JUKEN Classic Bluetooth RFCOMM/SPP transport already working in V11.1.9.
- Read the ECU Fuel Map row-by-row using the JUKEN map read protocol (1602;2;row -> 9602 response) before Auto Tune.
- Auto Tune uses real AFR vs Target AFR, averages multiple samples per cell, limits each correction step, and writes Fuel Map corrections through the row write protocol (2602;2;row;values).
- Auto Tune does not alter the calculator HTML or ignition map.

Auto Tune guardrails:
- RPM: 1500–16000
- TPS: 2–100%
- AFR deadband: 0.15 AFR-equivalent percentage error threshold
- Per-sample correction step capped at 5%
- Total correction capped at ±25%
- ECU write only after 8 samples for the same displayed RPM/TPS cell
- Ignition is never changed by Auto Tune

The app still requires a physical Android/ECU test to confirm the exact JUKEN firmware response on the user's ECU. The source is designed to fall back to live-data mode if map reading times out.

package com.rnautomap.jukenmod;

import android.Manifest;import android.app.*;import android.bluetooth.*;import android.content.*;import android.content.pm.PackageManager;import android.os.*;import android.webkit.*;import android.widget.*;import java.io.*;import java.nio.charset.StandardCharsets;import java.util.*;import java.util.UUID;

public class MainActivity extends Activity {
  WebView web; BluetoothAdapter bt; BluetoothSocket socket; OutputStream out; Thread rx; volatile boolean running=false; long lastLive=0;
  static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.setBackgroundColor(0xff080b10); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); web.addJavascriptInterface(new Bridge(),"Juken"); setContentView(web); web.loadUrl("file:///android_asset/index.html"); requestBtPerm();}
  void requestBtPerm(){ if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},91); }
  class Bridge {
    @JavascriptInterface public String paired(){ try{bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null)return "[]"; JSONArrayBuilder j=new JSONArrayBuilder(); if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)return "[]"; for(BluetoothDevice d:bt.getBondedDevices()) j.add(d.getName(),d.getAddress()); return j.out(); }catch(Exception e){return "[]";} }
    @JavascriptInterface public void connect(String mac){ new Thread(()->doConnect(mac)).start(); }
    @JavascriptInterface public void disconnect(){ close(); ui("btState('DISCONNECTED','Putus')"); }
    @JavascriptInterface public void send(String cmd){ sendRaw(cmd); }
    @JavascriptInterface public void openOriginal(){ try{Intent i=getPackageManager().getLaunchIntentForPackage("com.bintangracingteam.juken6"); if(i!=null)startActivity(i); else Toast.makeText(MainActivity.this,"APK JUKEN asli belum terpasang.",Toast.LENGTH_LONG).show();}catch(Exception e){}}
  }
  void doConnect(String mac){ try{close(); bt=BluetoothAdapter.getDefaultAdapter(); BluetoothDevice d=bt.getRemoteDevice(mac); ui("btState('CONNECTING','Menghubungkan '+"+q(d.getName())+")");
      BluetoothSocket s=null; Exception last=null; for(int i=0;i<3;i++){try{ if(Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED){s=d.createRfcommSocketToServiceRecord(SPP); s.connect(); last=null; break;}}catch(Exception e){last=e; try{Thread.sleep(250);}catch(Exception x){}}}
      if(s==null)throw last==null?new IOException("RFCOMM gagal"):last; socket=s; out=s.getOutputStream(); running=true; startRx(s.getInputStream()); ui("btState('CONNECTED','Terhubung • SPP')");
      // Observed original-JUKEN traffic order. This is replayed as transport, not claimed as universal protocol.
      sendRaw("160B"); new Handler(Looper.getMainLooper()).postDelayed(()->sendRaw("1606"),250);
  }catch(Exception e){ui("btState('ERROR','Gagal: '+"+q(e.getMessage())+")");close();}}
  void startRx(InputStream in){ rx=new Thread(()->{ByteArrayOutputStream line=new ByteArrayOutputStream(); byte[] buf=new byte[1024]; try{while(running){int n=in.read(buf); if(n<0)break; for(int i=0;i<n;i++){byte c=buf[i]; if(c=='\n'){String x=line.toString("UTF-8").trim();line.reset();if(!x.isEmpty())handle(x);} else if(c!='\r') line.write(c);} String chunk=new String(buf,0,n,StandardCharsets.UTF_8); if(chunk.toLowerCase().contains("a603;")) lastLive=System.currentTimeMillis();}}catch(Exception e){} });rx.start();}
  void handle(String x){ final String z=x; if(z.startsWith("9606"))sendRaw("1616"); else if(z.startsWith("9616;")){ui("identity("+q(z)+")");sendRaw("1500");} else if(z.startsWith("9500"))sendRaw("1B00"); else if(z.equalsIgnoreCase("1b01")){sendRaw("160A");} else if(z.startsWith("a603;")){parseLive(z);} ui("logLine("+q(z)+")"); }
  void parseLive(String x){try{String[] p=x.split(";"); if(p.length<6)return; double t=n(p,1),bat=n(p,2),rpm=n(p,4),eot=n(p,5)/10.0,afr=n(p,6); if(t>100)t=0; if(afr<8||afr>25)afr=0; ui("live("+t+","+bat+","+rpm+","+eot+","+afr+")");}catch(Exception ignored){}}
  double n(String[] a,int i){return i<a.length?Double.parseDouble(a[i]):0;}
  void sendRaw(String c){try{if(out!=null){out.write((c+"\r\n").getBytes(StandardCharsets.UTF_8));out.flush();ui("tx("+q(c)+")");}}catch(Exception e){}}
  void close(){running=false;try{if(out!=null)sendRaw("160B");}catch(Exception e){}try{if(socket!=null)socket.close();}catch(Exception e){}out=null;socket=null;}
  void ui(String js){runOnUiThread(()->{if(web!=null)web.evaluateJavascript("try{"+js+"}catch(e){}",null);});}
  static String q(String s){return "'"+(s==null?"":s.replace("\\","\\\\").replace("'","\\'").replace("\n"," "))+"'";}
  static class JSONArrayBuilder{StringBuilder b=new StringBuilder("[");boolean first=true;void add(String n,String a){if(!first)b.append(',');first=false;b.append("{\"name\":\"").append(esc(n)).append("\",\"mac\":\"").append(esc(a)).append("\"}");}String out(){return b.append(']').toString();}static String esc(String x){return x==null?"":x.replace("\\","\\\\").replace("\"","\\\"");}}
}

# JUKEN MOD MAX

Basis kerja: APK JUKEN asli yang disediakan pengguna.

Tambahan yang sudah dibuat pada layer mod:
- Live dashboard RPM/TPS/AFR/BAT/EOT
- Bluetooth Classic SPP
- Replay transport sequence observed from the original app: 160B -> 1606 -> 1616 -> 1500 -> 1B00 -> 160A
- Auto Tune UI with Target AFR and active-cell correction model
- 3D-style tuning surface
- Engine-spec starting-map estimator
- Base Map / Ignition display kept separate from Auto Tune
- Launch original JUKEN package if installed

Important: Fuel Correction ECU WRITE is intentionally locked. No unverified write command/checksum is transmitted.
The map estimator is a starting-point calculator, not an official BRT/JUKEN calibration.

RNAUTOMAP JUKEN V11.1.7

Android project for the RNAUTOMAP JUKEN app.

This build fixes the V11.1.7 Java compilation errors in MainActivity:
- connectInternal(String) is an outer MainActivity method and is callable from the pairing receiver and Bridge.
- readLoop() is an outer MainActivity method and is submitted explicitly to readExec.

The Bluetooth transport keeps Classic SPP, 160A live polling, and 160B stop behavior based on the verified strings found in the supplied JUKEN APK. No unverified live-data byte mapping is invented.

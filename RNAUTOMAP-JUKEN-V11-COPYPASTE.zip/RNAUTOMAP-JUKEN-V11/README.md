# RNAUTOMAP JUKEN V11

Fondasi baru: Android native Bluetooth Classic SPP + UI RNAUTOMAP + kalkulator HTML asli.

## Yang sudah ada
- Scan Bluetooth Classic, bukan hanya bonded devices.
- Prioritas visual JUKEN/BRT.
- Pairing lalu koneksi SPP.
- Raw data ECU ditampilkan tanpa mengarang nilai.
- Parser awal untuk format teks RPM/TPS/AFR/BAT/EOT/IAT.
- Fuel Correction 0% saat awal.
- TPS 0–100% dan RPM 1.000–16.000 pada tabel.
- 3D live surface bergerak berdasarkan correction yang benar-benar diterima parser.
- Kalkulator asli `kalkulator-peta-ecu.html` dipasang sebagai menu Kalkulator Map.

## Batas penting
Frame/protokol binary JUKEN untuk pembacaan map dan penulisan map belum dianggap terverifikasi hanya dari nama simbol di APK. Karena itu V11 tidak mengirim frame map-write tebakan. Raw stream ditampilkan agar tahap reverse-engineering bisa diverifikasi terhadap data dari ECU.

## Build
Project ini siap dipasang ke GitHub dan dibuild dengan GitHub Actions. Gunakan JDK 17 dan Android SDK yang tersedia di runner.

package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.UUID;

public class MainActivity extends Activity {
  WebView web; BluetoothAdapter bt; BluetoothSocket socket; OutputStream out; InputStream in; ExecutorService io=Executors.newSingleThreadExecutor();
  static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  final Handler h=new Handler(Looper.getMainLooper());
  final Set<String> seen=new HashSet<>();
  BroadcastReceiver receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){
    if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){ BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null) addDevice(d); }
    if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(i.getAction())) web.post(()->web.evaluateJavascript("window.btDiscoveryDone&&btDiscoveryDone()",null));
  }};
  @Override public void onCreate(Bundle b){super.onCreate(b); setupWeb(); requestBt(); IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); registerReceiver(receiver,f);}
  void setupWeb(){ web=new WebView(this); web.setBackgroundColor(0xff050b12); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.addJavascriptInterface(new Bridge(),"AndroidBT"); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/app.html"); }
  void requestBt(){ if(Build.VERSION.SDK_INT>=31) requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},41); }
  boolean ok(){return Build.VERSION.SDK_INT<31 || (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED);}
  void addDevice(BluetoothDevice d){ if(!ok()) return; String name=d.getName(); if(name==null) name="(tanpa nama)"; String addr=d.getAddress(); if(seen.add(addr)){ String j=name.toUpperCase(Locale.US).contains("JUKEN")||name.toUpperCase(Locale.US).contains("BRT")?"true":"false"; String js="window.btFound&&btFound("+q(name)+","+q(addr)+","+j+")"; web.post(()->web.evaluateJavascript(js,null)); } }
  String q(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
  public class Bridge{
    @JavascriptInterface public void scan(){ if(!ok()){requestBt();return;} bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null){msg("Bluetooth tidak tersedia");return;} if(!bt.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),42);return;} seen.clear(); web.post(()->web.evaluateJavascript("window.btScanStarted&&btScanStarted()",null)); bt.cancelDiscovery(); bt.startDiscovery(); }
    @JavascriptInterface public void connect(String addr){ if(!ok())return; io.submit(()->{try{ if(bt==null)bt=BluetoothAdapter.getDefaultAdapter(); bt.cancelDiscovery(); BluetoothDevice d=bt.getRemoteDevice(addr); if(d.getBondState()!=BluetoothDevice.BOND_BONDED){ h.post(()->web.evaluateJavascript("window.btPairingNeeded&&btPairingNeeded("+q(addr)+")",null)); return; } socket=d.createRfcommSocketToServiceRecord(SPP); socket.connect(); out=socket.getOutputStream(); in=socket.getInputStream(); h.post(()->web.evaluateJavascript("window.btConnected&&btConnected("+q(d.getName()==null?"JUKEN":d.getName())+")",null)); readLoop(); }catch(Exception e){h.post(()->web.evaluateJavascript("window.btError&&btError("+q(e.toString())+")",null)); close();}}); }
    @JavascriptInterface public void pairAndConnect(String addr){ if(!ok())return; try{BluetoothDevice d=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr); d.createBond(); h.postDelayed(()->connect(addr),1500);}catch(Exception e){msg(e.toString());} }
    @JavascriptInterface public void send(String s){io.submit(()->{try{if(out!=null){out.write(s.getBytes("UTF-8"));out.flush();}}catch(Exception e){}});}
    @JavascriptInterface public void disconnect(){close();}
    @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
  }
  void readLoop(){byte[] buf=new byte[4096]; ByteArrayOutputStream line=new ByteArrayOutputStream(); try{int n; while(socket!=null&&(n=in.read(buf))>0){String raw=new String(buf,0,n,"UTF-8"); h.post(()->web.evaluateJavascript("window.btRaw&&btRaw("+q(raw)+")",null)); }}catch(Exception e){} }
  void close(){try{if(socket!=null)socket.close();}catch(Exception e){} socket=null;out=null;in=null; h.post(()->web.evaluateJavascript("window.btDisconnected&&btDisconnected()",null));}
  void msg(String s){h.post(()->web.evaluateJavascript("window.btError&&btError("+q(s)+")",null));}
  @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception e){}close();io.shutdownNow();super.onDestroy();}
}

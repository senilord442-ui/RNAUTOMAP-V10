package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.UUID;

public class MainActivity extends Activity {
  WebView web; BluetoothAdapter bt; BluetoothSocket socket; OutputStream out; InputStream in; ExecutorService io=Executors.newSingleThreadExecutor(); ExecutorService readExec=Executors.newSingleThreadExecutor(); ScheduledExecutorService livePoll=Executors.newSingleThreadScheduledExecutor(); final Object txLock=new Object();
  static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  final Handler h=new Handler(Looper.getMainLooper());
  final Set<String> seen=new HashSet<>(); String pendingPairAddress=null;
  BroadcastReceiver receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){
    if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){ BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null) addDevice(d); }
    if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(i.getAction())) web.post(()->web.evaluateJavascript("window.btDiscoveryDone&&btDiscoveryDone()",null));
    if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(i.getAction())){
      BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
      int state=i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE,BluetoothDevice.ERROR);
      if(d!=null && state==BluetoothDevice.BOND_BONDED && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        String addr=pendingPairAddress; pendingPairAddress=null; h.postDelayed(()->MainActivity.this.connectInternal(addr),250);
      }
      if(d!=null && state==BluetoothDevice.BOND_NONE && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        pendingPairAddress=null; msg("Pairing Bluetooth gagal");
      }
    }
  }};
  @Override public void onCreate(Bundle b){super.onCreate(b); setupWeb(); requestBt(); IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED); if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_EXPORTED); else registerReceiver(receiver,f);}
  void setupWeb(){ web=new WebView(this); web.setBackgroundColor(0xff050b12); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.addJavascriptInterface(new Bridge(),"AndroidBT"); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/app.html"); }
  void requestBt(){
    if(Build.VERSION.SDK_INT>=31){
      requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},41);
    }else if(Build.VERSION.SDK_INT>=23){
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},42);
    }
  }
  boolean ok(){
    if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
    if(Build.VERSION.SDK_INT>=23) return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    return true;
  }
  void addDevice(BluetoothDevice d){ if(!ok()) return; String name=d.getName(); if(name==null) name="(tanpa nama)"; String addr=d.getAddress(); if(seen.add(addr)){ String j=name.toUpperCase(Locale.US).contains("JUKEN")||name.toUpperCase(Locale.US).contains("BRT")?"true":"false"; String js="window.btFound&&btFound("+q(name)+","+q(addr)+","+j+")"; web.post(()->web.evaluateJavascript(js,null)); } }
  String q(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
  public class Bridge{
    @JavascriptInterface public void scan(){ if(!ok()){requestBt();return;} bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null){msg("Bluetooth tidak tersedia");return;} if(!bt.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),42);return;} seen.clear(); web.post(()->web.evaluateJavascript("window.btScanStarted&&btScanStarted()",null)); for(BluetoothDevice d:bt.getBondedDevices()) addDevice(d); bt.cancelDiscovery(); bt.startDiscovery(); }
    @JavascriptInterface public void connect(String addr){ if(!ok())return; connectInternal(addr); }
    @JavascriptInterface public void pairAndConnect(String addr){ if(!ok())return; try{
      BluetoothDevice d=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr);
      if(d.getBondState()==BluetoothDevice.BOND_BONDED){ MainActivity.this.connectInternal(addr); return; }
      pendingPairAddress=addr;
      boolean started=d.createBond();
      if(!started){ pendingPairAddress=null; msg("Permintaan pairing tidak diterima Bluetooth"); }
    }catch(Exception e){ pendingPairAddress=null; msg(e.toString()); } }
    @JavascriptInterface public void send(String s){sendRaw(s);}
    @JavascriptInterface public void startLive(){startJukenLivePolling();}
    @JavascriptInterface public void stopLive(){stopJukenLivePolling(); sendRaw("160B\r\n");}
    @JavascriptInterface public void disconnect(){close();}
    @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
  }
  void connectInternal(String addr){
    io.submit(()->{
      try{
        if(bt==null) bt=BluetoothAdapter.getDefaultAdapter();
        if(bt==null){ msg("Bluetooth tidak tersedia"); return; }
        bt.cancelDiscovery();
        BluetoothDevice d=bt.getRemoteDevice(addr);
        if(d.getBondState()!=BluetoothDevice.BOND_BONDED){
          pendingPairAddress=addr;
          h.post(()->web.evaluateJavascript("window.btPairingNeeded&&btPairingNeeded("+q(addr)+")",null));
          return;
        }

        closeSocketOnly();

        try{
          socket=d.createRfcommSocketToServiceRecord(SPP);
          socket.connect();
        }catch(IOException e){
          closeSocketOnly();
          socket=d.createInsecureRfcommSocketToServiceRecord(SPP);
          socket.connect();
        }

        out=socket.getOutputStream();
        in=socket.getInputStream();

        String nm=d.getName()==null?"JUKEN":d.getName();
        h.post(()->web.evaluateJavascript("window.btConnected&&btConnected("+q(nm)+")",null));

        startJukenLivePolling();
        readExec.submit(MainActivity.this::readLoop);

      }catch(Exception e){
        h.post(()->web.evaluateJavascript("window.btError&&btError("+q(e.toString())+")",null));
        close();
      }
    });
  }

  void sendRaw(String s){
    synchronized(txLock){
      try{
        if(out!=null && socket!=null && socket.isConnected()){
          out.write(s.getBytes("US-ASCII"));
          out.flush();
        }
      }catch(Exception e){ }
    }
  }
  void startJukenLivePolling(){stopJukenLivePolling(); livePoll.scheduleAtFixedRate(()->sendRaw("160A\r\n"),0,500,TimeUnit.MILLISECONDS);}
  void stopJukenLivePolling(){try{livePoll.shutdownNow();}catch(Exception e){} livePoll=Executors.newSingleThreadScheduledExecutor();}
  void readLoop(){
    byte[] buf=new byte[4096];
    try{
      int n;
      while(socket!=null && in!=null && (n=in.read(buf))>0){
        final byte[] packet=Arrays.copyOf(buf,n);
        final String raw=new String(packet,"UTF-8");
        final String hex=toHex(packet);
        h.post(()->web.evaluateJavascript("window.btRaw&&btRaw("+q(raw)+")",null));
        h.post(()->web.evaluateJavascript("window.btHex&&btHex("+q(hex)+")",null));
      }
    }catch(Exception e){ }
  }
  String toHex(byte[] b){
    StringBuilder z=new StringBuilder(b.length*3);
    for(byte v:b) z.append(String.format(Locale.US,"%02X ",v&0xFF));
    return z.toString().trim();
  }
  void closeSocketOnly(){
    try{if(socket!=null)socket.close();}catch(Exception e){}
    socket=null; out=null; in=null;
  }
  void close(){
    stopJukenLivePolling();
    sendRaw("160B\r\n");
    closeSocketOnly();
    h.post(()->web.evaluateJavascript("window.btDisconnected&&btDisconnected()",null));
  }
  void msg(String s){h.post(()->web.evaluateJavascript("window.btError&&btError("+q(s)+")",null));}
  @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception e){}close();io.shutdownNow();readExec.shutdownNow();livePoll.shutdownNow(); super.onDestroy();}
}

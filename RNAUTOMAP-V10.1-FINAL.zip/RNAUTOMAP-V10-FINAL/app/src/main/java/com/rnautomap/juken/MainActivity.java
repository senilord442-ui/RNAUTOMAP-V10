package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int REQ_BT = 77;
    private static final int REQ_ENABLE_BT = 78;
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private InputStream in;
    private OutputStream out;
    private WebView web;
    private final AtomicBoolean stopRead = new AtomicBoolean(false);
    private final Map<String, BluetoothDevice> found = new LinkedHashMap<>();
    private BroadcastReceiver receiver;
    private volatile String pendingPairAddress = null;
    private volatile boolean scanning = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setBackgroundColor(0xff02070d);
        web.addJavascriptInterface(new JsBridge(), "JukenBT");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        registerBtReceiver();
        web.loadUrl("file:///android_asset/kalkulator-peta-ecu.html");
        requestBtPermissions();
    }

    private void requestBtPermissions() {
        ArrayList<String> p = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_CONNECT);
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), REQ_BT);
    }

    private boolean allowedScan() {
        if (Build.VERSION.SDK_INT >= 31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean allowedConnect() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    private BluetoothAdapter getAdapter() {
        if (adapter == null) adapter = BluetoothAdapter.getDefaultAdapter();
        return adapter;
    }

    private void registerBtReceiver() {
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String a = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(a)) {
                    BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d != null) addFound(d);
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(a)) {
                    scanning = false;
                    emitScan(false);
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(a)) {
                    BluetoothDevice d = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                    if (d == null) return;
                    int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR);
                    if (state == BluetoothDevice.BOND_BONDED && pendingPairAddress != null && pendingPairAddress.equals(safeAddress(d))) {
                        pendingPairAddress = null;
                        emitState(false, safeName(d), "PAIRING BERHASIL • menghubungkan…");
                        connectDevice(d);
                    } else if (state == BluetoothDevice.BOND_NONE && pendingPairAddress != null && pendingPairAddress.equals(safeAddress(d))) {
                        pendingPairAddress = null;
                        emitState(false, safeName(d), "Pairing dibatalkan/gagal");
                    }
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(BluetoothDevice.ACTION_FOUND);
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(receiver, f);
    }

    private void addFound(BluetoothDevice d) {
        String name = safeName(d);
        String addr = safeAddress(d);
        if (addr == null || addr.isEmpty()) return;
        if (!isJuken(name)) return;
        found.put(addr, d);
        emitScan(scanning);
    }

    private boolean isJuken(String name) {
        String n = name == null ? "" : name.toUpperCase(Locale.US);
        return n.contains("JUKEN") || n.contains("BRT");
    }

    private String safeName(BluetoothDevice d) {
        try { return d.getName() == null ? "Perangkat Bluetooth" : d.getName(); }
        catch (Exception e) { return "Perangkat Bluetooth"; }
    }

    private String safeAddress(BluetoothDevice d) {
        try { return d.getAddress(); } catch (Exception e) { return ""; }
    }

    private void emitScan(boolean isScanning) {
        JSONArray arr = new JSONArray();
        for (BluetoothDevice d : found.values()) {
            try {
                JSONObject o = new JSONObject();
                o.put("name", safeName(d));
                o.put("address", safeAddress(d));
                o.put("bonded", d.getBondState() == BluetoothDevice.BOND_BONDED);
                arr.put(o);
            } catch (Exception ignored) {}
        }
        String js = "window.onBtScan&&window.onBtScan(" + arr + "," + isScanning + ")";
        runOnUiThread(() -> web.evaluateJavascript(js, null));
    }

    private void startScan() {
        if (!allowedScan()) { requestBtPermissions(); emitState(false, "", "Izinkan Bluetooth / lokasi untuk scan"); return; }
        BluetoothAdapter ad = getAdapter();
        if (ad == null) { emitState(false, "", "HP tidak mendukung Bluetooth"); return; }
        if (!ad.isEnabled()) {
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_ENABLE_BT); }
            catch (Exception e) { emitState(false, "", "Nyalakan Bluetooth Android"); }
            return;
        }
        try { ad.cancelDiscovery(); } catch (Exception ignored) {}
        found.clear(); scanning = true; emitScan(true);
        boolean ok;
        try { ok = ad.startDiscovery(); } catch (Exception e) { ok = false; }
        if (!ok) { scanning = false; emitState(false, "", "Scan Bluetooth gagal dimulai"); emitScan(false); }
    }

    private void stopScan() {
        BluetoothAdapter ad = getAdapter();
        try { if (ad != null) ad.cancelDiscovery(); } catch (Exception ignored) {}
        scanning = false; emitScan(false);
    }

    private void pairAndConnect(String address) {
        if (!allowedConnect()) { requestBtPermissions(); return; }
        BluetoothAdapter ad = getAdapter();
        if (ad == null) { emitState(false, "", "Bluetooth tidak tersedia"); return; }
        BluetoothDevice d;
        try { d = ad.getRemoteDevice(address); } catch (Exception e) { emitState(false, "", "Perangkat tidak valid"); return; }
        stopScan();
        try {
            if (d.getBondState() == BluetoothDevice.BOND_BONDED) {
                connectDevice(d);
            } else {
                pendingPairAddress = address;
                emitState(false, safeName(d), "Menunggu dialog pairing Android…");
                boolean started = d.createBond();
                if (!started) { pendingPairAddress = null; emitState(false, safeName(d), "Android gagal memulai pairing"); }
            }
        } catch (Exception e) { emitState(false, safeName(d), "Pairing error: " + shortErr(e)); }
    }

    private void connectDevice(final BluetoothDevice dev) {
        new Thread(() -> {
            closeSocket();
            emitState(false, safeName(dev), "Menghubungkan via Bluetooth Classic…");
            BluetoothSocket s = null;
            try {
                try {
                    s = dev.createRfcommSocketToServiceRecord(SPP);
                    s.connect();
                } catch (Exception first) {
                    try { if (s != null) s.close(); } catch (Exception ignored) {}
                    s = dev.createInsecureRfcommSocketToServiceRecord(SPP);
                    s.connect();
                }
                socket = s; in = s.getInputStream(); out = s.getOutputStream(); stopRead.set(false);
                emitState(true, safeName(dev), "CONNECTED • SPP");
                readLoop();
            } catch (Exception e) {
                try { if (s != null) s.close(); } catch (Exception ignored) {}
                emitState(false, safeName(dev), "Gagal konek: " + shortErr(e));
                closeSocket();
            }
        }, "JUKEN-BT-CONNECT").start();
    }

    private String shortErr(Exception e) { return e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(); }

    private void emitState(boolean connected, String name, String msg) {
        String j = "{\"connected\":" + connected + ",\"name\":\"" + esc(name) + "\",\"message\":\"" + esc(msg) + "\"}";
        runOnUiThread(() -> web.evaluateJavascript("window.onBtState&&window.onBtState(" + j + ")", null));
    }

    private void emitRaw(String raw) {
        String j = "\"" + esc(raw) + "\"";
        runOnUiThread(() -> web.evaluateJavascript("window.onJukenRaw&&window.onJukenRaw(" + j + ")", null));
    }

    private String esc(String s) { if (s == null) return ""; return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "\\n"); }

    private void readLoop() {
        byte[] b = new byte[4096];
        ByteArrayOutputStream acc = new ByteArrayOutputStream();
        try {
            while (!stopRead.get() && socket != null && socket.isConnected()) {
                int n = in.read(b);
                if (n <= 0) break;
                String chunk = new String(b, 0, n, StandardCharsets.US_ASCII);
                emitRaw(chunk);
                acc.write(b, 0, n);
                parseAccumulated(acc);
                if (acc.size() > 32768) {
                    byte[] q = acc.toByteArray(); acc.reset(); acc.write(q, Math.max(0, q.length - 8192), Math.min(8192, q.length));
                }
            }
        } catch (Exception e) {
            if (!stopRead.get()) emitState(false, "", "Koneksi Bluetooth terputus");
        } finally { closeSocket(); }
    }

    private void parseAccumulated(ByteArrayOutputStream acc) {
        byte[] a = acc.toByteArray();
        int start = 0;
        while (true) {
            int p = indexOfAscii(a, "a603;", start);
            if (p < 0) break;
            int end = -1;
            for (int i = p; i < a.length - 1; i++) {
                if (a[i] == '\r' || a[i] == '\n') { end = i; break; }
                if (i > p + 6 && a[i] == 'a' && regionEqualsIgnoreCase(a, i, "a603;")) { end = i; break; }
            }
            if (end < 0) {
                if (p > 0) { acc.reset(); acc.write(a, p, a.length - p); }
                return;
            }
            String frame = new String(a, p, end - p, StandardCharsets.US_ASCII).trim();
            if (!frame.isEmpty()) parseFrame(frame);
            start = end + 1;
            while (start < a.length && (a[start] == '\r' || a[start] == '\n')) start++;
            if (start >= a.length) { acc.reset(); return; }
        }
        if (start > 0) { acc.reset(); acc.write(a, start, a.length - start); }
    }

    private int indexOfAscii(byte[] a, String needle, int from) {
        byte[] n = needle.getBytes(StandardCharsets.US_ASCII);
        outer: for (int i = from; i <= a.length - n.length; i++) { for (int j=0;j<n.length;j++) if (Character.toLowerCase((char)a[i+j]) != Character.toLowerCase((char)n[j])) continue outer; return i; }
        return -1;
    }
    private boolean regionEqualsIgnoreCase(byte[] a, int p, String s) { return indexOfAscii(a, s, p) == p; }

    // The field mapping below is intentionally isolated: it is the currently observed A603 parser shape,
    // not a claim that every JUKEN firmware uses the same positions. Raw frames are always retained in the UI.
    private void parseFrame(String raw) {
        String f = raw.substring(Math.max(0, raw.toLowerCase(Locale.US).indexOf("a603;")));
        String[] p = f.split(";");
        if (p.length < 13) return;
        try {
            int tpsRaw = Integer.parseInt(p[1].trim());
            double bat = Double.parseDouble(p[2].trim());
            int rpm = Integer.parseInt(p[4].trim());
            double eot = Double.parseDouble(p[5].trim()) / 10.0;
            double afr = Double.parseDouble(p[7].trim());
            double inj = Double.parseDouble(p[9].trim());
            double ign = Double.parseDouble(p[10].trim()) / 10.0;
            double iat = Double.parseDouble(p[12].trim()) / 10.0;
            int tps = tpsRaw <= 0 ? 0 : (tpsRaw == 1 ? 5 : (tpsRaw <= 19 ? tpsRaw * 5 - 5 : 100));
            JSONObject j = new JSONObject();
            j.put("rpm", rpm); j.put("tps", tps); j.put("afr", afr); j.put("bat", bat); j.put("eot", eot); j.put("iat", iat); j.put("inj", inj); j.put("ign", ign); j.put("raw", f);
            runOnUiThread(() -> web.evaluateJavascript("window.onJukenLive&&window.onJukenLive(" + j + ")", null));
        } catch (Exception ignored) {}
    }

    private synchronized void sendRaw(String s) {
        try { if (out != null) { out.write(s.getBytes(StandardCharsets.US_ASCII)); out.flush(); } }
        catch (Exception ignored) {}
    }

    private synchronized void closeSocket() {
        stopRead.set(true);
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null; in = null; out = null;
    }

    @Override protected void onDestroy() {
        stopScan(); closeSocket();
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    public class JsBridge {
        @JavascriptInterface public void startScan() { MainActivity.this.startScan(); }
        @JavascriptInterface public void stopScan() { MainActivity.this.stopScan(); }
        @JavascriptInterface public void listDiscovered() { emitScan(scanning); }
        @JavascriptInterface public void pairAndConnect(String address) { MainActivity.this.pairAndConnect(address); }
        @JavascriptInterface public void disconnect() { closeSocket(); emitState(false, "", "Disconnected"); }
        @JavascriptInterface public void startLive() { if (socket == null || !socket.isConnected()) { emitState(false, "", "Hubungkan JUKEN dulu"); return; } sendRaw("160A\r\n"); emitState(true, "JUKEN", "LIVE request dikirim • menunggu data"); }
        @JavascriptInterface public void stopLive() { sendRaw("160B\r\n"); emitState(socket != null && socket.isConnected(), "JUKEN", "Live dihentikan"); }
        @JavascriptInterface public void send(String command) { sendRaw(command == null ? "" : command); }
        @JavascriptInterface public boolean isConnected() { return socket != null && socket.isConnected(); }
    }
}

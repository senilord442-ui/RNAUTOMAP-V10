# RNAUTOMAP V10.1 — Juken Companion

- New V10 dark/cyan dashboard UI.
- Direct Bluetooth Classic SPP scan, pairing and connection.
- JUKEN/BRT device filtering.
- Raw Bluetooth monitor.
- Live RPM/TPS/AFR/BAT/EOT/IAT bridge.
- Existing ECU calculator retained and extended with exhaust type.
- Base Fuel Map + Base Ignition Map + 3D view.
- Fuel Correction remains separate from Base Map.

Safety: ECU map write is intentionally not enabled until the JUKEN write protocol is verified against real hardware/frames.

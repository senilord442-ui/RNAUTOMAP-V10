# RNAUTOMAP V11.1.16 — JUKEN PAIR-FIRST

GitHub-ready Android source.

Connection flow: Scan -> Pair/Bond -> RFCOMM/SPP -> response-driven JUKEN init -> ECU identity -> LIVE RX.

The app does not hard-code a Bluetooth PIN because JUKEN modules can require different pairing codes. Android/module pairing handles the code.

Added features: engine/map calculator, Base Map + Ignition calculation UI, Auto Mapping UI, AFR targets, and 3D TPS × RPM correction graph.

Fuel Correction WRITE remains disabled until the exact original JUKEN write/checksum command is captured and verified. No guessed ECU write command is transmitted.

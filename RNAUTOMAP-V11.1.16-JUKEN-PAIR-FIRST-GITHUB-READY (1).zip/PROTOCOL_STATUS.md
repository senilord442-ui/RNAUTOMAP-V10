# Protocol status — V11.1.16

Captured / implemented:
- Bluetooth Classic RFCOMM/SPP
- UUID 00001101-0000-1000-8000-00805F9B34FB
- Captured RFCOMM SCN 1 fallback
- Pair/Bond before ECU protocol traffic; no hard-coded PIN
- 160B -> 1A00
- 1606 -> 9606;...
- 1616 -> 9616;... identity
- 1500 -> 9500;...
- 1B00 -> 1b01
- 160A -> 1A00 -> A603;... live frames

Not guessed / disabled:
- Fuel Correction WRITE payload and checksum
- Universal map-write protocol for all JUKEN firmware
- Bluetooth PIN/passkey

package com.rnautomap.juken;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.SharedPreferences;
import android.os.*;
import android.webkit.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.UUID;
import java.lang.reflect.Method;

public class MainActivity extends Activity {
  WebView web; BluetoothAdapter bt; BluetoothSocket socket; OutputStream out; InputStream in; ExecutorService io=Executors.newSingleThreadExecutor(); ExecutorService readExec=Executors.newSingleThreadExecutor(); ScheduledExecutorService livePoll=Executors.newSingleThreadScheduledExecutor(); final Object txLock=new Object();
  static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
  final Handler h=new Handler(Looper.getMainLooper());
  final Set<String> seen=new HashSet<>(); String pendingPairAddress=null;
  BroadcastReceiver receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){
    if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){ BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); if(d!=null) addDevice(d); }
    if(BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(i.getAction())) web.post(()->web.evaluateJavascript("window.btDiscoveryDone&&btDiscoveryDone()",null));
    if(BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(i.getAction())){
      BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
      if(d!=null){ h.post(()->web.evaluateJavascript("window.btError&&btError("+q("Bluetooth JUKEN terputus")+")",null)); }
    }
    if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(i.getAction())){
      BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
      int state=i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE,BluetoothDevice.ERROR);
      if(d!=null && state==BluetoothDevice.BOND_BONDED && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        String addr=pendingPairAddress; pendingPairAddress=null; h.postDelayed(()->MainActivity.this.connectInternal(addr),250);
      }
      if(d!=null && state==BluetoothDevice.BOND_NONE && pendingPairAddress!=null && pendingPairAddress.equals(d.getAddress())){
        pendingPairAddress=null; msg("Pairing Bluetooth gagal");
      }
    }
  }};
  @Override public void onCreate(Bundle b){super.onCreate(b); setupWeb(); requestBt(); IntentFilter f=new IntentFilter(); f.addAction(BluetoothDevice.ACTION_FOUND); f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED); f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED); f.addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED); if(Build.VERSION.SDK_INT>=33) registerReceiver(receiver,f,Context.RECEIVER_EXPORTED); else registerReceiver(receiver,f);}
  void setupWeb(){ web=new WebView(this); web.setBackgroundColor(0xff050b12); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setAllowFileAccess(true); web.getSettings().setAllowFileAccessFromFileURLs(true); web.getSettings().setAllowUniversalAccessFromFileURLs(true); web.addJavascriptInterface(new Bridge(),"AndroidBT"); web.setWebViewClient(new WebViewClient()); setContentView(web); web.loadUrl("file:///android_asset/app.html"); }
  void requestBt(){
    if(Build.VERSION.SDK_INT>=31){
      requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN,Manifest.permission.BLUETOOTH_CONNECT},41);
    }else if(Build.VERSION.SDK_INT>=23){
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},42);
    }
  }
  boolean ok(){
    if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
    if(Build.VERSION.SDK_INT>=23) return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    return true;
  }
  void addDevice(BluetoothDevice d){ if(!ok()) return; String name=d.getName(); if(name==null) name="(tanpa nama)"; String addr=d.getAddress(); if(seen.add(addr)){ String j=name.toUpperCase(Locale.US).contains("JUKEN")||name.toUpperCase(Locale.US).contains("BRT")?"true":"false"; String js="window.btFound&&btFound("+q(name)+","+q(addr)+","+j+")"; web.post(()->web.evaluateJavascript(js,null)); } }
  String q(String s){return "'"+s.replace("\\","\\\\").replace("'","\\'")+"'";}
  SharedPreferences prefs(){ return getSharedPreferences("rnautomap", MODE_PRIVATE); }
  public class Bridge{
    @JavascriptInterface public void scan(){ if(!ok()){requestBt();return;} bt=BluetoothAdapter.getDefaultAdapter(); if(bt==null){msg("Bluetooth tidak tersedia");return;} if(!bt.isEnabled()){startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE),42);return;} seen.clear(); web.post(()->web.evaluateJavascript("window.btScanStarted&&btScanStarted()",null)); for(BluetoothDevice d:bt.getBondedDevices()) addDevice(d); bt.cancelDiscovery(); bt.startDiscovery(); }
    @JavascriptInterface public void connect(String addr){ if(!ok())return; connectInternal(addr); }
    @JavascriptInterface public void pairAndConnect(String addr){ if(!ok())return; try{
      BluetoothDevice d=BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr);
      if(d.getBondState()==BluetoothDevice.BOND_BONDED){ MainActivity.this.connectInternal(addr); return; }
      pendingPairAddress=addr;
      boolean started=d.createBond();
      if(!started){ pendingPairAddress=null; msg("Permintaan pairing tidak diterima Bluetooth"); }
    }catch(Exception e){ pendingPairAddress=null; msg(e.toString()); } }
    @JavascriptInterface public void send(String s){sendRaw(s);}
    @JavascriptInterface public void startLive(){startJukenLivePolling();}
    @JavascriptInterface public void stopLive(){stopJukenLivePolling(); sendRaw("160B\r\n");}
    @JavascriptInterface public void disconnect(){close();}
    @JavascriptInterface public boolean isConnected(){return socket!=null&&socket.isConnected();}
    @JavascriptInterface public void saveCalculatorData(String json){
      if(json==null || json.length()<10) return;
      prefs().edit().putString("calculator_data",json).apply();
    }
    @JavascriptInterface public String getCalculatorData(){
      return prefs().getString("calculator_data","");
    }
    @JavascriptInterface public void saveTargets(String json){
      if(json==null || json.length()<2) return;
      prefs().edit().putString("targets",json).apply();
    }
    @JavascriptInterface public String getTargets(){
      return prefs().getString("targets","");
    }
  }
  void connectInternal(String addr){
    io.submit(()->{
      try{
        if(bt==null) bt=BluetoothAdapter.getDefaultAdapter();
        if(bt==null){ msg("Bluetooth tidak tersedia"); return; }
        bt.cancelDiscovery();

        BluetoothDevice d=bt.getRemoteDevice(addr);
        if(d.getBondState()!=BluetoothDevice.BOND_BONDED){
          pendingPairAddress=addr;
          h.post(()->web.evaluateJavascript("window.btPairingStarted&&btPairingStarted("+q(addr)+")",null));
          boolean started=d.createBond();
          if(!started){
            pendingPairAddress=null;
            throw new IOException("Bluetooth JUKEN belum terpasang dan permintaan pairing ditolak Android");
          }
          return;
        }

        closeSocketOnly();
        notifyConn("MENGHUBUNGKAN KE "+(d.getName()==null?"JUKEN":d.getName()));

        BluetoothSocket connected=null;
        StringBuilder errors=new StringBuilder();

        // The original JUKEN APK contains flutter_bluetooth_serial, whose
        // documented transport is Bluetooth Classic RFCOMM/SPP. Retry the
        // standard SPP path, then advertised UUIDs, then bounded RFCOMM
        // channel fallbacks so stale Android SDP state does not strand us.
        for(int attempt=1; attempt<=3 && connected==null; attempt++){
          notifyConn("MENGHUBUNGKAN KE JUKEN (COBA "+attempt+"/3)");
          try{ d.fetchUuidsWithSdp(); }catch(Exception ignored){}
          try{ Thread.sleep(900); }catch(InterruptedException ie){ Thread.currentThread().interrupt(); }

          // Insecure SPP first for older serial modules.
          connected=trySocket(d,SPP,false,errors);
          // Secure SPP is the normal Bluetooth Serial API path.
          if(connected==null) connected=trySocket(d,SPP,true,errors);

          // Try every RFCOMM service UUID actually advertised by the device.
          if(connected==null){
            try{
              ParcelUuid[] uuids=d.getUuids();
              if(uuids!=null){
                for(ParcelUuid pu:uuids){
                  if(pu==null) continue;
                  connected=tryUuidSocket(d,pu.getUuid(),errors);
                  if(connected!=null) break;
                }
              }
            }catch(Exception ignored){}
          }

          // Bounded channel probing as a final compatibility path.
          if(connected==null){
            for(int ch=1;ch<=8 && connected==null;ch++){
              connected=tryChannel(d,ch,false,errors);
              if(connected==null) connected=tryChannel(d,ch,true,errors);
            }
          }
        }

        if(connected==null){
          String detail=errors.length()>0?errors.toString():"tidak ada metode RFCOMM yang berhasil";
          throw new IOException("Koneksi JUKEN gagal: "+detail);
        }

        socket=connected;
        out=socket.getOutputStream();
        in=socket.getInputStream();

        String nm=d.getName()==null?"JUKEN":d.getName();
        h.post(()->web.evaluateJavascript("window.btConnected&&btConnected("+q(nm)+")",null));

        readExec.submit(MainActivity.this::readLoop);
        startJukenLivePolling();

      }catch(Exception e){
        h.post(()->web.evaluateJavascript("window.btError&&btError("+q(e.toString())+")",null));
        close();
      }
    });
  }

  BluetoothSocket trySocket(BluetoothDevice d, UUID uuid, boolean secure, StringBuilder errors){
    return trySocketOnce(d,uuid,secure,errors);
  }

  BluetoothSocket tryUuidSocket(BluetoothDevice d, UUID uuid, StringBuilder errors){
    BluetoothSocket s=trySocketOnce(d,uuid,true,errors);
    if(s==null) s=trySocketOnce(d,uuid,false,errors);
    return s;
  }

  BluetoothSocket trySocketOnce(BluetoothDevice d, UUID uuid, boolean secure, StringBuilder errors){
    BluetoothSocket s=null;
    try{
      bt.cancelDiscovery();
      s=secure?d.createRfcommSocketToServiceRecord(uuid):d.createInsecureRfcommSocketToServiceRecord(uuid);
      s.connect();
      return s;
    }catch(Exception e){
      if(s!=null) try{s.close();}catch(Exception ignored){}
      if(errors.length()<1800) errors.append("[UUID ").append(uuid).append(secure?" secure":" insecure").append("] ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append(" ");
      return null;
    }
  }

  BluetoothSocket tryChannel(BluetoothDevice d, int channel, boolean insecure, StringBuilder errors){
    BluetoothSocket s=null;
    try{
      bt.cancelDiscovery();
      Method m=d.getClass().getMethod(insecure?"createInsecureRfcommSocket":"createRfcommSocket", int.class);
      s=(BluetoothSocket)m.invoke(d,channel);
      s.connect();
      return s;
    }catch(Exception e){
      if(s!=null) try{s.close();}catch(Exception ignored){}
      if(errors.length()<1800) errors.append("[RFCOMM").append(channel).append(" ").append(insecure?"insecure":"secure").append("] ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append(" ");
      return null;
    }
  }

  void notifyConn(String s){
    h.post(()->web.evaluateJavascript("window.btConnecting&&btConnecting("+q(s)+")",null));
  }

  void sendRaw(String s){
    synchronized(txLock){
      try{
        if(out!=null && socket!=null && socket.isConnected()){
          out.write(s.getBytes("US-ASCII"));
          out.flush();
        }
      }catch(Exception e){ }
    }
  }
  void startJukenLivePolling(){stopJukenLivePolling(); livePoll.scheduleAtFixedRate(()->sendRaw("160A\r\n"),0,500,TimeUnit.MILLISECONDS);}
  void stopJukenLivePolling(){try{livePoll.shutdownNow();}catch(Exception e){} livePoll=Executors.newSingleThreadScheduledExecutor();}
  void readLoop(){
    byte[] buf=new byte[4096];
    try{
      int n;
      while(socket!=null && in!=null && (n=in.read(buf))>0){
        final byte[] packet=Arrays.copyOf(buf,n);
        final String raw=new String(packet,"UTF-8");
        final String hex=toHex(packet);
        h.post(()->web.evaluateJavascript("window.btRaw&&btRaw("+q(raw)+")",null));
        h.post(()->web.evaluateJavascript("window.btHex&&btHex("+q(hex)+")",null));
      }
    }catch(Exception e){ }
  }
  String toHex(byte[] b){
    StringBuilder z=new StringBuilder(b.length*3);
    for(byte v:b) z.append(String.format(Locale.US,"%02X ",v&0xFF));
    return z.toString().trim();
  }
  void closeSocketOnly(){
    try{if(socket!=null)socket.close();}catch(Exception e){}
    socket=null; out=null; in=null;
  }
  void close(){
    stopJukenLivePolling();
    sendRaw("160B\r\n");
    closeSocketOnly();
    h.post(()->web.evaluateJavascript("window.btDisconnected&&btDisconnected()",null));
  }
  void msg(String s){h.post(()->web.evaluateJavascript("window.btError&&btError("+q(s)+")",null));}
  @Override protected void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception e){}close();io.shutdownNow();readExec.shutdownNow();livePoll.shutdownNow(); super.onDestroy();}
}

# RNAUTOMAP V11.1.20 — Rotatable Auto Tune Graph

Android source project based on the supplied V11.1.19 archive.

- Changes are limited to the Auto Tune 3D graph and its small in-graph controls.
- Horizontal drag rotates the graph through 360 degrees; vertical drag changes viewing tilt; Reset returns the default angle.
- The plotted surface uses the saved Base Fuel Map as its visual baseline and Fuel Correction as a separate adjustment. The source Base Map is not mutated by drawing.
- The active-cell marker appears only when genuine live TPS/RPM readings have been received.
- If a Base Map is not synchronized, the graph shows a prompt instead of presenting a fake green map.
- Original Bluetooth / native protocol code and the other menus are unchanged.
- Fuel Correction CSV export and calculator exports are retained.

Build with the existing GitHub Actions workflow after uploading this ZIP to the repository. Validate the live marker and map shape on the target device before tuning.

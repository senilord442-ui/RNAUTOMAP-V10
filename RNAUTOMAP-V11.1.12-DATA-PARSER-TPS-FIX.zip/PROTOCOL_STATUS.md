# RNAUTOMAP V11.1.12 — protocol evidence status

## Proven from real user data

- Transport: Bluetooth Classic RFCOMM/SPP is supported by the original JUKEN APK (`flutter_bluetooth_serial`).
- Verified live request: `160A\r\n` appears in the original APK.
- Verified live stop: `160B\r\n` appears in the original APK.
- Verified live frame prefix: `a603` appears in the original APK and in the user's real RAW capture.
- Verified real frame:
  `a603;0;13.21;2;0;340;20.00;0;0;0;0;610;0;0\r\n`
- Verified display values from the user's original JUKEN screen: RPM 0, TPS 0%, AFR 20.00, BAT 13.21 V, EOT 34.0 C, IAT 0.0 C.
- Therefore the parser uses: TPS raw field 0, battery field 1, RPM field 3, EOT field 4 / 10, AFR field 5, IAT field 10 / 10.

## Deliberately not claimed as proven

- Non-zero TPS conversion (`ConvertTpsJss` exists in the APK, but the supplied real frame only proves the zero point).
- Exact JUKEN Fuel Map read payload/checksum.
- Exact JUKEN Fuel Correction write payload/checksum.
- Exact EXECUTE transaction.

The app therefore does not send guessed map read/write commands. Auto Tune calculates and displays Fuel Correction locally from real AFR vs target, with positive correction meaning more fuel when measured AFR is leaner than target. ECU writes remain disabled until a real original-app transaction is captured and verified.

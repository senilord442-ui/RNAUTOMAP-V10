# RNAUTOMAP V11.1.12 — protocol evidence status

## Proven from real user data

- Transport: Bluetooth Classic RFCOMM/SPP is supported by the original JUKEN APK (`flutter_bluetooth_serial`).
- Verified live request: `160A\r\n` appears in the original APK.
- Verified live stop: `160B\r\n` appears in the original APK.
- Verified live frame prefix: `a603` appears in the original APK and in the user's real RAW capture.
- Verified real frame:
  `a603;0;13.21;2;0;340;20.00;0;0;0;0;610;0;0\r\n`
- Verified display values from the user's original JUKEN screen: RPM 0, TPS 0%, AFR 20.00, BAT 13.21 V, EOT 34.0 C, IAT 0.0 C.
- Therefore the parser uses: TPS raw field 0, battery field 1, RPM field 3, EOT field 4 / 10, AFR field 5, IAT field 10 / 10.

## Deliberately not claimed as proven

- Non-zero TPS conversion (`ConvertTpsJss` exists in the APK, but the supplied real frame only proves the zero point).
- Exact JUKEN Fuel Map read payload/checksum.
- Exact JUKEN Fuel Correction write payload/checksum.
- Exact EXECUTE transaction.

The app therefore does not send guessed map read/write commands. Auto Tune calculates and displays Fuel Correction locally from real AFR vs target, with positive correction meaning more fuel when measured AFR is leaner than target. ECU writes remain disabled until a real original-app transaction is captured and verified.


## V11.1.12 DATA PARSER/TPS FIX2
- RX reader is started before live command.
- Live start uses 160A\r\n with one controlled retry if no RX bytes arrive.
- UI shows cumulative JUKEN RX byte count.
- A603 parser accepts the observed AFR position and the public-reference AFR position, choosing a plausible AFR range.
- IAT is read from the final live token used by the observed unit.
